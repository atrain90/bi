<?php
/**
 * WP Framework
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

namespace Joomunited\WPFramework\v1_0_4;

defined('ABSPATH') || die();

/**
 * Class Installer
 */
class Installer
{

}
