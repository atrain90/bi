<?php
/**
 * WP Framework
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

namespace Joomunited\WPFramework\v1_0_4\Fields;

use Joomunited\WPFramework\v1_0_4\Field;

defined('ABSPATH') || die();

/**
 * Class Submit
 */
class Submit extends Button
{
}
