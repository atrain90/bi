# Joomunited Framework
## Potential backward compatibility issues from in 1.0.3
### Controller
#### exit_status method has been removed
Use existStatus method instead, parameters have not changed