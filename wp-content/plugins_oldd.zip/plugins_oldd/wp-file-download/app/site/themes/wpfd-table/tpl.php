<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0.3
 */

//-- No direct access
defined('ABSPATH') || die();

$download_category = empty($this->files) ? 'display-download-category' : '';
$showsubcategories = ((int) WpfdBase::loadValue($this->params, 'table_showsubcategories', 1) === 1) ? true : false;
$showfoldertree    = ((int) WpfdBase::loadValue($this->params, 'table_showfoldertree', 0) === 1) ? true : false;
?>

<script type="text/x-handlebars-template"
        id="wpfd-template-table-categories-<?php echo esc_attr($this->category->term_id); ?>">
    {{#if category}}
    {{#with category}}
    <h2>
        <?php if ((int) WpfdBase::loadValue($this->params, 'table_showcategorytitle', 1) === 1) : ?>
        {{name}}
        <?php endif; ?>
        {{#if parent}}
        <a class="catlink wpfdcategory backcategory" href="#" data-idcat="{{parent}}"><i
                    class="zmdi zmdi-chevron-left"></i><?php esc_html_e('Back', 'wpfd'); ?></a>
        {{/if}}
    </h2>
    {{/with}}
    {{/if}}

    <?php if ((int) WpfdBase::loadValue($this->params, 'table_showsubcategories', 1) === 1) : ?>
        {{#if categories}}
        {{#each categories}}
        <a class="catlink wpfdcategory" href="#" data-idcat="{{term_id}}"><span>{{name}}</span><i
                    class="zmdi zmdi-folder wpfd-folder"></i></a>
        {{/each}}
        {{/if}}
    <?php endif; ?>

</script>

<script type="text/x-handlebars-template" id="wpfd-template-table-<?php echo esc_attr($this->category->term_id); ?>">

    {{#if files}}
    {{#each files}}
    <tr class="file" data-id="{{ID}}" data-catid="{{catid}}">
        <?php if ((int) WpfdBase::loadValue($this->params, 'table_showtitle', 1) === 1) : ?>
            <td>
                <a class="wpfd_downloadlink" href="{{linkdownload}}" title="{{post_title}}">
                        <span class="extcol">
                        <?php if ($this->config['custom_icon']) : ?>
                            {{#if file_custom_icon}}
                            <span class="icon-custom"><img src="{{file_custom_icon}}"></span>
                            {{else}}
                            <span class="ext {{ext}}"></span>
                            {{/if}}
                        <?php else : ?>
                            <span class="ext {{ext}}"></span>
                        <?php endif; ?>
                        </span>{{crop_title}}
                </a>
            </td>
        <?php endif; ?>

        <?php if ((int) WpfdBase::loadValue($this->params, 'table_showversion', 1) === 1) : ?>
            <td>
                {{versionNumber}}
            </td>
        <?php endif; ?>

        <?php if ((int) WpfdBase::loadValue($this->params, 'table_showdescription', 1) === 1) : ?>
            <td>
                {{{description}}}
            </td>
        <?php endif; ?>

        <?php if ((int) WpfdBase::loadValue($this->params, 'table_showsize', 1) === 1) : ?>
            <td>
                {{bytesToSize size}}
            </td>
        <?php endif; ?>

        <?php if ((int) WpfdBase::loadValue($this->params, 'table_showhits', 1) === 1) : ?>
            <td>
                {{hits}}
            </td>
        <?php endif; ?>

        <?php if ((int) WpfdBase::loadValue($this->params, 'table_showdateadd', 0) === 1) : ?>
            <td>
                {{created}}
            </td>
        <?php endif; ?>

        <?php if ((int) WpfdBase::loadValue($this->params, 'table_showdatemodified', 0) === 1) : ?>
            <td>
                {{modified}}
            </td>
        <?php endif; ?>

        <?php if ((int) WpfdBase::loadValue($this->params, 'table_showdownload', 1) === 1) : ?>
            <?php
            $bg_download    = WpfdBase::loadValue($this->params, 'table_bgdownloadlink', '');
            $color_download = WpfdBase::loadValue($this->params, 'table_colordownloadlink', '');
            $download_style = '';
            if ($bg_download !== '') {
                $download_style .= 'background-color:' . $bg_download . ';';
            }
            if ($color_download !== '') {
                $download_style .= 'color:' . $color_download . ';';
            }
            ?>
            <td class="col-download">
                <a class="downloadlink wpfd_downloadlink"
                   href="{{linkdownload}}" style="<?php echo esc_attr($download_style); ?>">
                    <?php esc_html_e('Download', 'wpfd'); ?><i class="zmdi zmdi-cloud-download wpfd-download"></i></a>
                {{#if openpdflink}}
                <a href="{{openpdflink}}" class="openlink" target="_blank"><?php esc_html_e('Preview', 'wpfd'); ?>
                    <i class="zmdi zmdi-filter-center-focus wpfd-preview"></i></a>
                {{else}}
                {{#if viewerlink}}
                <?php
                $viewer_attr = 'openlink wpfdlightbox wpfd_previewlink';
                $target      = '';
                if ($this->config['use_google_viewer'] === 'tab') {
                    $viewer_attr = 'openlink wpfd_previewlink';
                    $target      = '_blank';
                } ?>
                <a href="{{viewerlink}}" class="<?php echo esc_attr($viewer_attr); ?>"
                   target="<?php echo esc_attr($target); ?>" data-id="{{ID}}" data-catid="{{catid}}"
                   data-file-type="{{ext}}">
                    <?php esc_html_e('Preview', 'wpfd'); ?><i
                            class="zmdi zmdi-filter-center-focus wpfd-preview"></i></a>
                {{/if}}
                {{/if}}

            </td>
        <?php endif; ?>

    </tr>
    {{/each}}
    {{/if}}


</script>
<?php if (!empty($this->category)) : ?>
    <?php if (!empty($this->files) || !empty($this->categories)) : ?>
        <div class="wpfd-content wpfd-content-table wpfd-content-multi <?php echo esc_attr($this->wpfdclass); ?>"
             data-category="<?php echo esc_attr($this->category->term_id); ?>">
            <input type="hidden" id="current_category" value="<?php echo esc_attr($this->category->term_id); ?>"/>
            <input type="hidden" id="current_category_slug" value="<?php echo esc_attr($this->category->slug); ?>"/>
            <?php if ((int) WpfdBase::loadValue($this->params, 'table_showbreadcrumb', 1) === 1) : ?>
                <ul class="breadcrumbs wpfd-breadcrumbs-table head-category-table">
                    <li class="active">
                        <?php echo esc_html($this->category->name); ?>
                    </li>
                    <?php if ($this->config['download_category'] && !$this->categoryFrom) : ?>
                        <a data-catid=""
                           class="download-category <?php echo esc_attr($download_category); ?>"
                           href="<?php echo esc_url($this->category->linkdownload_cat); ?> ">
                            <?php esc_html_e('Download all ', 'wpfd'); ?>
                            <i class="zmdi zmdi-check-all wpfd-download-category"></i>
                        </a>
                    <?php endif; ?>
                </ul>
            <?php elseif ($this->config['download_category'] && !$this->categoryFrom) : ?>
                <ul class="head-category-table">
                    <li>
                        &nbsp;
                    </li>
                    <?php if ($this->config['download_category'] && !$this->categoryFrom) : ?>
                        <a data-catid=""
                           class="download-category <?php echo esc_attr($download_category); ?>"
                           href="<?php echo esc_url($this->category->linkdownload_cat); ?> ">
                            <?php esc_html_e('Download all ', 'wpfd'); ?>
                            <i class="zmdi zmdi-check-all wpfd-download-category"></i>
                        </a>
                    <?php endif; ?>
                </ul>
            <?php endif; ?>

            <div class="wpfd-flex-container">
                <?php if ((int) WpfdBase::loadValue($this->params, 'table_showfoldertree', 0) === 1) : ?>
                    <div class="wpfd-foldertree-table <?php echo esc_attr($showsubcategories ? 'foldertreetable-hide' : ''); ?>">
                    </div>
                <?php endif; ?>
                <div class="wpfd-container-table<?php echo ((int) WpfdBase::loadValue($this->params, 'table_showfoldertree', 0) === 1) ? ' with_foldertree' : ''; ?>">
                    <div class="wpfd-categories">
                        <?php if ((int) WpfdBase::loadValue($this->params, 'table_showcategorytitle', 1) === 1) : ?>
                            <h2><?php echo esc_html($this->category->name); ?></h2>
                        <?php endif; ?>
                        <?php if (count($this->categories) &&
                                  (int) WpfdBase::loadValue($this->params, 'table_showsubcategories', 1) === 1) : ?>
                            <?php foreach ($this->categories as $category) : ?>
                                <a class="wpfdcategory catlink" href="#"
                                   data-idcat="<?php echo esc_attr($category->term_id); ?>"
                                   title="<?php echo esc_html($category->name); ?>">
                                    <span><?php echo esc_html($category->name); ?></span>
                                    <i class="zmdi zmdi-folder wpfd-folder"></i>
                                </a>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>

                    <table class="<?php echo esc_attr($this->tableclass); ?> mediaTable">

                        <thead>
                        <tr>
                            <?php if ((int) WpfdBase::loadValue($this->params, 'table_showtitle', 1) === 1) : ?>
                                <th class="essential persist">
                                    <?php esc_html_e('Title', 'wpfd'); ?>
                                </th>
                            <?php endif; ?>

                            <?php if ((int) WpfdBase::loadValue($this->params, 'table_showversion', 1) === 1) : ?>
                                <th class="optional">
                                    <?php esc_html_e('Version', 'wpfd'); ?>
                                </th>
                            <?php endif; ?>

                            <?php if ((int) WpfdBase::loadValue($this->params, 'table_showdescription', 1) === 1) : ?>
                                <th class="optional">
                                    <?php esc_html_e('Description', 'wpfd'); ?>
                                </th>
                            <?php endif; ?>

                            <?php if ((int) WpfdBase::loadValue($this->params, 'table_showsize', 1) === 1) : ?>
                                <th class="optional">
                                    <?php esc_html_e('Size', 'wpfd'); ?>
                                </th>
                            <?php endif; ?>

                            <?php if ((int) WpfdBase::loadValue($this->params, 'table_showhits', 1) === 1) : ?>
                                <th class="optional">
                                    <?php esc_html_e('Hits', 'wpfd'); ?>
                                </th>
                            <?php endif; ?>

                            <?php if ((int) WpfdBase::loadValue($this->params, 'table_showdateadd', 0) === 1) : ?>
                                <th class="optional">
                                    <?php esc_html_e('Date added', 'wpfd'); ?>
                                </th>
                            <?php endif; ?>

                            <?php if ((int) WpfdBase::loadValue($this->params, 'table_showdatemodified', 0) === 1) : ?>
                                <th class="optional">
                                    <?php esc_html_e('Date modified', 'wpfd'); ?>
                                </th>
                            <?php endif; ?>


                            <?php if ((int) WpfdBase::loadValue($this->params, 'table_showdownload', 1) === 1) : ?>
                                <th class="essential">
                                    <?php esc_html_e('Download', 'wpfd'); ?>
                                </th>
                            <?php endif; ?>
                        </tr>
                        </thead>
                        <tbody>

                        <?php foreach ($this->files as $file) : ?>
                            <tr class="file" data-id="<?php echo esc_attr($file->ID); ?>"
                                data-catid="<?php echo esc_attr($file->catid); ?>">
                                <?php if ((int) WpfdBase::loadValue($this->params, 'table_showtitle', 1) === 1) : ?>
                                    <td>
                                        <a class="wpfd_downloadlink"
                                           href="<?php echo esc_url($file->linkdownload); ?>"
                                           title="<?php echo esc_attr($file->post_title); ?>">
                                            <?php if ($this->config['custom_icon'] && $file->file_custom_icon) : ?>
                                                <span class="icon-custom">
                                                    <img src="<?php echo esc_url($file->file_custom_icon); ?>">
                                                    <span class="icon-custom-title">
                                                        <?php echo esc_html($file->crop_title); ?>
                                                    </span>
                                                </span>
                                            <?php else : ?>
                                                <span class="extcol">
                                                    <span class="ext <?php echo esc_attr(strtolower($file->ext)); ?>"></span>
                                                    <?php echo esc_html($file->crop_title); ?>
                                                </span>
                                            <?php endif; ?>
                                        </a>
                                    </td>
                                <?php endif; ?>

                                <?php if ((int) WpfdBase::loadValue($this->params, 'table_showversion', 1) === 1) : ?>
                                    <td>
                                        <?php echo esc_html(!empty($file->versionNumber) ? $file->versionNumber : ''); ?>
                                    </td>
                                <?php endif; ?>

                                <?php if ((int) WpfdBase::loadValue($this->params, 'table_showdescription', 1) === 1) : ?>
                                    <td>
                                        <?php
                                        if (!empty($file->description)) {
                                            // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Used wpfd_esc_desc to remove <script>
                                            echo wpfd_esc_desc($file->description);
                                        }
                                        ?>
                                    </td>
                                <?php endif; ?>

                                <?php if ((int) WpfdBase::loadValue($this->params, 'table_showsize', 1) === 1) : ?>
                                    <td>
                                        <?php $fileSize = ($file->size === 'n/a') ?
                                            $file->size : WpfdHelperFile::bytesToSize($file->size);
                                        echo esc_html($fileSize);
                                        ?>
                                    </td>
                                <?php endif; ?>

                                <?php if ((int) WpfdBase::loadValue($this->params, 'table_showhits', 1) === 1) : ?>
                                    <td>
                                        <?php echo esc_html($file->hits); ?>
                                    </td>
                                <?php endif; ?>

                                <?php if ((int) WpfdBase::loadValue($this->params, 'table_showdateadd', 0) === 1) : ?>
                                    <td>
                                        <?php echo esc_html($file->created); ?>
                                    </td>
                                <?php endif; ?>

                                <?php if ((int) WpfdBase::loadValue($this->params, 'table_showdatemodified', 0) === 1) : ?>
                                    <td>
                                        <?php echo esc_html($file->modified); ?>
                                    </td>
                                <?php endif; ?>

                                <?php if ((int) WpfdBase::loadValue($this->params, 'table_showdownload', 1) === 1) : ?>
                                    <?php
                                    $bg_download    = WpfdBase::loadValue($this->params, 'table_bgdownloadlink', '');
                                    $color_download = WpfdBase::loadValue($this->params, 'table_colordownloadlink', '');
                                    $download_style = '';
                                    if ($bg_download !== '') {
                                        $download_style .= 'background-color:' . $bg_download . ';';
                                    }
                                    if ($color_download !== '') {
                                        $download_style .= 'color:' . $color_download . ';';
                                    }
                                    ?>
                                    <td class="col-download">
                                        <a class="downloadlink wpfd_downloadlink"
                                           href="<?php echo esc_html($file->linkdownload) ?>" style="<?php echo esc_html($download_style); ?>">
                                            <?php esc_html_e('Download', 'wpfd'); ?><i
                                                    class="zmdi zmdi-cloud-download wpfd-download"></i></a>
                                        <?php if (isset($file->openpdflink)) { ?>
                                            <a href="<?php echo esc_url($file->openpdflink); ?>" class="openlink"
                                               target="_blank">
                                                <?php esc_html_e('Preview', 'wpfd'); ?><i
                                                        class="zmdi zmdi-filter-center-focus wpfd-preview"></i></a>
                                        <?php } else { ?>
                                            <?php if (isset($file->viewerlink)) { ?>
                                                <?php
                                                $viewer_attr = 'openlink wpfdlightbox wpfd_previewlink';
                                                $target      = '';
                                                if ($file->viewer_type === 'tab') {
                                                    $viewer_attr = 'openlink wpfd_previewlink';
                                                    $target      = '_blank';
                                                } ?>
                                                <a href="<?php echo esc_url($file->viewerlink); ?>"
                                                   class="<?php echo esc_attr($viewer_attr); ?>"
                                                   target="<?php echo esc_attr($target); ?>"
                                                   data-id="<?php echo esc_attr($file->ID); ?>"
                                                   data-catid="<?php echo esc_attr($file->catid); ?>"
                                                   data-file-type="<?php echo esc_attr(strtolower($file->ext)); ?>">
                                                    <?php esc_html_e('Preview', 'wpfd'); ?><i
                                                            class="zmdi zmdi-filter-center-focus wpfd-preview"></i></a>
                                            <?php } ?>
                                        <?php } ?>

                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>

                    </table>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

