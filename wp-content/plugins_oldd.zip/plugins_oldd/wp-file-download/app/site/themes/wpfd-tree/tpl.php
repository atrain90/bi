<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0.3
 */

//-- No direct access
defined('ABSPATH') || die();

$download_category = empty($this->files) ? 'display-download-category' : '';
?>
    <script type="text/x-handlebars-template" id="wpfd-template-tree-box">
        {{#with file}}
        <div class="dropblock">
            <a href="javascript:void(null)" class="wpfd-close"></a>
            <div class="filecontent">
                <?php if ($this->config['custom_icon']) : ?>
                    {{#if file_custom_icon}}
                    <div class="ext icon-custom" style="background: none;"><img
                                src="<?php echo esc_url($this->siteurl); ?>{{file_custom_icon}}"></div>
                    {{else}}
                    <div class="ext {{ext}}"><span class="txt">{{ext}}</div>
                    {{/if}}
                <?php else : ?>
                    <div class="ext {{ext}}"><span class="txt">{{ext}}</div>
                <?php endif; ?>

                <?php if ((int) WpfdBase::loadValue($this->params, 'tree_showtitle', 1) === 1) : ?>
                    <h3><a class="downloadlink wpfd_downloadlink" href="{{linkdownload}}" title="{{post_title}}">
                            {{crop_title}} </a>
                    </h3>
                <?php endif; ?>

                <div class="wpfd-extra">
                    <?php if ((int) WpfdBase::loadValue($this->params, 'tree_showdescription', 1) === 1) : ?>
                        {{#if description}}
                        <div class="file-desc">
                            <span><?php esc_html_e('Description', 'wpfd'); ?> : </span>{{{description}}}&nbsp;
                        </div>
                        {{/if}}
                    <?php endif; ?>
                    <?php if ((int) WpfdBase::loadValue($this->params, 'tree_showversion', 1) === 1) : ?>
                        {{#if versionNumber}}
                        <div class="file-version">
                            <span><?php esc_html_e('Version', 'wpfd'); ?> : </span> {{versionNumber}}&nbsp;
                        </div>
                        {{/if}}
                    <?php endif; ?>
                    <?php if ((int) WpfdBase::loadValue($this->params, 'tree_showsize', 1) === 1) : ?>
                        {{#if size}}
                        <div class="file-size"><span><?php esc_html_e('Size', 'wpfd'); ?> : </span> {{bytesToSize size}}</div>
                        {{/if}}
                    <?php endif; ?>
                    <?php if ((int) WpfdBase::loadValue($this->params, 'tree_showhits', 1) === 1) : ?>
                        {{#if hits}}
                        <div class="file-hits"><span><?php esc_html_e('Hits', 'wpfd'); ?> : </span> {{hits}}</div>
                        {{/if}}
                    <?php endif; ?>
                    <?php if ((int) WpfdBase::loadValue($this->params, 'tree_showdateadd', 1) === 1) : ?>
                        {{#if created}}
                        <div class="file-dated"><span><?php esc_html_e('Date added', 'wpfd'); ?> : </span> {{created}}</div>
                        {{/if}}
                    <?php endif; ?>
                    <?php if ((int) WpfdBase::loadValue($this->params, 'tree_showdatemodified', 1) === 1) : ?>
                        {{#if modified}}
                        <div class="file-modified"><span><?php esc_html_e('Date modified', 'wpfd'); ?> : </span> {{modified}}
                        </div>
                        {{/if}}
                    <?php endif; ?>
                </div>
            </div>

            <?php if ((int) WpfdBase::loadValue($this->params, 'tree_showdownload', 1) === 1) :
                $bg_download = WpfdBase::loadValue($this->params, 'tree_bgdownloadlink', '');
                $color_download = WpfdBase::loadValue($this->params, 'tree_colordownloadlink', '');
                $download_style = '';
                if ($bg_download !== '') {
                    $download_style .= 'background-color:' . $bg_download . ';';
                }
                if ($color_download !== '') {
                    $download_style .= 'color:' . $color_download . ';';
                }
                ?>
                <div class="extra-downloadlink">
                    <a class="wpfd_downloadlink"
                       href="{{linkdownload}}" style="<?php echo esc_html($download_style); ?>"><?php esc_html_e('Download', 'wpfd'); ?><i
                                class="zmdi zmdi-cloud-download wpfd-download"></i></a>

                    {{#if openpdflink}}
                    <div class="viewerlink">
                        <a href="{{openpdflink}}" target="_blank" class="wpfd_previewlink ">
                            <?php esc_html_e('Preview', 'wpfd'); ?>
                            <i class="zmdi zmdi-filter-center-focus wpfd-preview"></i>
                        </a>
                    </div>
                    {{else}}
                    {{#if viewerlink}}
                    <?php
                    $viewer_attr = 'openlink wpfdlightbox wpfd_previewlink';
                    $target = '';
                    if ($this->config['use_google_viewer'] === 'tab') {
                        $viewer_attr = 'openlink wpfd_previewlink';
                        $target = '_blank';
                    } ?>
                    <div class="viewerlink">
                        <a href="{{viewerlink}}" class="<?php echo esc_attr($viewer_attr); ?>" target="<?php echo esc_attr($target); ?>" data-id="{{ID}}" data-catid="{{catid}}"
                           data-file-type="{{ext}}"><?php esc_html_e('Preview', 'wpfd'); ?><i
                                    class="zmdi zmdi-filter-center-focus wpfd-preview"></i>
                        </a>
                    </div>
                    {{/if}}
                    {{/if}}
                </div>
            <?php endif; ?>
        </div>
        {{/with}}
    </script>


<?php if ((int) WpfdBase::loadValue($this->params, 'tree_showsubcategories', 1) === 1) : ?>
    <script type="text/x-handlebars-template" id="wpfd-template-tree-categories">
        {{#if categories}}
        {{#each categories}}
        <li class="directory collapsed">
            <a class="catlink" href="#" data-idcat="{{term_id}}">
                <div class="icon-open-close" data-id="{{term_id}}"></div>
                <i class="zmdi zmdi-folder wpfd-folder"></i>
                <span>{{name}}</span>
            </a>
        </li>
        {{/each}}
        {{/if}}
    </script>
<?php endif; ?>

    <script type="text/x-handlebars-template" id="wpfd-template-tree-files">
        {{#if files}}
        {{#each files}}
        <li class="ext {{ext}}">
            <?php if ($this->config['custom_icon']) : ?>
                {{#if file_custom_icon}}
                <span class="wpfd-file ext icon-custom"><img src="{{file_custom_icon}}"></span>
                {{else}}
                <i class="wpfd-file ext {{ext}}"></i>
                {{/if}}
            <?php else : ?>
                <i class="wpfd-file ext {{ext}}"></i>
            <?php endif; ?>

            <a class="wpfd-file-link" data-category_id="{{catid}}" href="<?php $atthref = '#';
            if ((int) WpfdBase::loadValue($this->params, 'tree_download_popup', 1) === 0) {
                $atthref = '{{linkdownload}}';
            }
            echo esc_html($atthref); ?>" data-id="{{ID}}"
               title="{{post_title}}">{{crop_title}}</a>
        </li>
        {{/each}}
        </div>
        {{/if}}
    </script>
<?php if ($this->category !== null) : ?>
    <?php if (!empty($this->files) || !empty($this->categories)) : ?>
        <div class="wpfd-content wpfd-content-tree wpfd-content-multi"
             data-category="<?php echo esc_attr($this->category->term_id); ?>">
            <input type="hidden" id="root_linkdownload_cat" value="<?php echo esc_attr($this->category->linkdownload_cat); ?>"/>
            <input type="hidden" id="root_countfile_cat" value="<?php echo esc_attr(count($this->files)); ?>"/>
            <?php if ((int) WpfdBase::loadValue($this->params, 'tree_showcategorytitle', 1) === 1) : ?>
                <h2><?php echo esc_html($this->category->name); ?>
                    <?php if ($this->config['download_category'] && !$this->categoryFrom) : ?>
                        <a data-catid="" class="tree-download-category <?php echo esc_attr($download_category); ?>"
                           href="<?php echo esc_url($this->category->linkdownload_cat); ?> ">
                            <?php esc_html_e('Download all ', 'wpfd'); ?>
                            <i class="zmdi zmdi-check-all wpfd-download-category"></i>
                        </a>
                    <?php endif; ?>
                </h2>
            <?php elseif ($this->config['download_category'] && !$this->categoryFrom) : ?>
                <div class="head-category-tree">
                    <div class="display-inline-block">
                        &nbsp;
                    </div>
                    <?php if ($this->config['download_category'] && !$this->categoryFrom) : ?>
                        <a data-catid="" class="tree-download-category <?php echo esc_attr($download_category); ?>"
                           href="<?php echo esc_url($this->category->linkdownload_cat); ?> ">
                            <?php esc_html_e('Download all ', 'wpfd'); ?>
                            <i class="zmdi zmdi-check-all wpfd-download-category"></i>
                        </a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            <ul>
                <?php if (count($this->categories) &&
                          (int) WpfdBase::loadValue($this->params, 'tree_showsubcategories', 1) === 1) : ?>
                    <?php foreach ($this->categories as $category) : ?>
                        <li class="directory collapsed">
                            <a class="catlink" href="#" data-idcat="<?php echo esc_attr($category->term_id); ?>">
                                <div class="icon-open-close" data-id="<?php echo esc_attr($category->term_id); ?>"></div>
                                <i class="zmdi zmdi-folder wpfd-folder"></i>
                                <span><?php echo esc_html($category->name); ?></span>
                            </a>
                        </li>
                    <?php endforeach; ?>
                <?php endif; ?>
                <?php if (is_array($this->files) && count($this->files)) : ?>
                    <?php foreach ($this->files as $file) : ?>
                        <li class="ext <?php echo esc_attr(strtolower($file->ext)); ?>">
                            <?php if ($this->config['custom_icon'] && $file->file_custom_icon) : ?>
                                <i class="wpfd-file"><img src="<?php echo esc_url($file->file_custom_icon); ?>"></i>
                            <?php else : ?>
                                <i class="wpfd-file ext <?php echo esc_attr(strtolower($file->ext)); ?>"></i>
                            <?php endif; ?>
                            <a class="wpfd-file-link" href="<?php $atthref = '#';
                            if ((int) WpfdBase::loadValue($this->params, 'tree_download_popup', 1) === 0) {
                                $atthref = $file->linkdownload;
                            }
                            echo esc_url($atthref); ?>" data-category_id="<?php echo esc_attr($file->catid); ?>"
                               data-id="<?php echo esc_attr($file->ID); ?>"
                               title="<?php echo esc_attr($file->post_title); ?>"><?php echo esc_html($file->crop_title); ?></a>
                        </li>
                    <?php endforeach; ?>
                <?php endif; ?>
            </ul>
        </div>
    <?php endif; ?>
<?php endif; ?>

