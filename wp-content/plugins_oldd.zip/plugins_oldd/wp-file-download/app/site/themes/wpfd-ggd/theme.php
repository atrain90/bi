<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

//-- No direct access
defined('ABSPATH') || die();

/**
 * Class WpfdThemeGgd
 */
class WpfdThemeGgd
{

    /**
     * Theme name
     *
     * @var string
     */
    public $name = 'ggd';

    /**
     * Ajax url
     *
     * @var string
     */
    private $ajaxUrl = '';

    /**
     * Plugin path
     *
     * @var string
     */
    private $path = '';

    /**
     * Config
     *
     * @var array
     */

    private $config = array();

    /**
     * Options
     *
     * @var array
     */
    protected $options;

    /**
     * Get theme name
     *
     * @return string
     */
    public function getThemeName()
    {
        return $this->name;
    }

    /**
     * Set ajax url
     *
     * @param string $url Ajaxurl
     *
     * @return void
     */
    public function setAjaxUrl($url)
    {
        $this->ajaxUrl = $url;
    }

    /**
     * Set path
     *
     * @param string $path Plugin path
     *
     * @return void
     */
    public function setPath($path)
    {
        $this->path = $path;
    }

    /**
     * Set config
     *
     * @param array $config Configs
     *
     * @return void
     */
    public function setConfig($config)
    {
        $this->config = $config;
    }

    /**
     * Show category
     *
     * @param array $options Options
     *
     * @return string
     */
    public function showCategory($options)
    {
        if (empty($options['files']) && empty($options['categories'])) {
            return '';
        }
        $this->options = $options;

        // Load css and scripts
        $this->loadAssets();
        $this->loadLightboxAssets();

        $content            = '';
        $this->siteurl      = get_site_url();
        $this->files        = $this->options['files'];
        $this->category     = $this->options['category'];
        $this->categoryFrom = apply_filters('wpfdAddonCategoryFrom', $this->category->term_id);

        if ((int) $this->categoryFrom === $this->category->term_id) {
            $this->categoryFrom = false;
        }
        $this->categories = $this->options['categories'];
        $this->params     = $this->options['params'];


        if (!empty($this->options['files']) ||
            (int) WpfdBase::loadValue($this->params, 'ggd_showsubcategories', 1) === 1 ||
            WpfdBase::loadValue($this->params, 'ggd_showfoldertree', 0)
        ) {
            $style = '.wpfd-content-ggd .wpfd-file-link, .wpfd-content-ggd .wpfdcategory {margin : ';
            $style .= WpfdBase::loadValue($this->params, 'ggd_margintop', 5) . 'px ';
            $style .= WpfdBase::loadValue($this->params, 'ggd_marginright', 5) . 'px ';
            $style .= WpfdBase::loadValue($this->params, 'ggd_marginbottom', 5) . 'px ';
            $style .= WpfdBase::loadValue($this->params, 'ggd_marginleft', 5) . 'px;}';

            if (!WpfdBase::loadValue($this->params, 'ggd_showborder', true)) {
                $style .= ' .wpfd-content .dropblock {box-shadow: none;';
                $style .= '-moz-box-shadow: none; -webkit-box-shadow: none;}';
            }
            wp_add_inline_style('wpfd-theme-ggd', $style);

            ob_start();
            require dirname(__FILE__) . DIRECTORY_SEPARATOR . 'tpl.php';
            $content = ob_get_contents();
            ob_end_clean();

            // Fix conflict with wpautop in VC
            $content = str_replace(array("\n", "\r"), '', $content);
        }

        return $content;
    }


    /**
     * Load theme styles and scripts
     *
     * @return void
     */
    private function loadAssets()
    {
        if (WpfdBase::checkExistTheme($this->name)) {
            $url = plugin_dir_url(__FILE__);
        } else {
            $dirs = wp_get_upload_dir();
            $url  = $dirs['baseurl'] . '/wpfd-themes/wpfd-' . $this->name . '/';
        }

        wp_enqueue_script('jquery');
        wp_enqueue_script('handlebars', $url . 'js/handlebars-1.0.0-rc.3.js');
        wp_enqueue_style(
            'wpfd-material-design',
            plugins_url('app/site/assets/css/material-design-iconic-font.min.css', WPFD_PLUGIN_FILE),
            array(),
            WPFD_VERSION
        );
        wp_enqueue_script(
            'wpfd-front',
            plugins_url('app/site/assets/js/front.js', WPFD_PLUGIN_FILE),
            array(),
            WPFD_VERSION
        );
        wp_localize_script('wpfd-front', 'wpfdparams', array(
            'wpfdajaxurl'          => $this->ajaxUrl,
            'ga_download_tracking' => $this->config['ga_download_tracking'],
            'ajaxadminurl'         => admin_url('admin-ajax.php') . '?juwpfisadmin=0'
        ));
        if ((int) WpfdBase::loadValue($this->options['params'], 'ggd_showfoldertree', 0) === 1) {
            wp_enqueue_script(
                'wpfd-foldertree',
                plugins_url('app/site/assets/js/jaofiletree.js', WPFD_PLUGIN_FILE),
                array(),
                WPFD_VERSION
            );
            wp_enqueue_style(
                'wpfd-foldertree',
                plugins_url('app/site/assets/css/jaofiletree.css', WPFD_PLUGIN_FILE),
                array(),
                WPFD_VERSION
            );
        }
        wp_enqueue_script('wpfd-theme-ggd', $url . 'js/script.js', array(), WPFD_VERSION);
        $path_foobar = $this->path . DIRECTORY_SEPARATOR . 'site' . DIRECTORY_SEPARATOR . 'foobar';
        wp_enqueue_script(
            'wpfd-helper',
            plugins_url('assets/js/helper.js', $path_foobar)
        );
        wp_localize_script('wpfd-theme-ggd', 'wpfdGgdTheme', array('wpfdajaxurl' => $this->ajaxUrl));
        wp_enqueue_style('wpfd-theme-ggd', $url . 'css/style.css', array(), WPFD_VERSION);
    }

    /**
     * Load Lightbox style and scripts
     *
     * @return void
     */
    private function loadLightboxAssets()
    {
        if ($this->config['use_google_viewer'] === 'lightbox') {
            wp_enqueue_style(
                'wpfd-videojs',
                plugins_url('app/site/assets/css/video-js.css', WPFD_PLUGIN_FILE),
                array(),
                WPFD_VERSION
            );
            wp_enqueue_style(
                'wpfd-colorbox',
                plugins_url('app/site/assets/css/colorbox.css', WPFD_PLUGIN_FILE),
                array(),
                WPFD_VERSION
            );
            wp_enqueue_style(
                'wpfd-viewer',
                plugins_url('app/site/assets/css/viewer.css', WPFD_PLUGIN_FILE),
                array(),
                WPFD_VERSION
            );
            wp_enqueue_script(
                'wpfd-videojs',
                plugins_url('app/site/assets/js/video.js', WPFD_PLUGIN_FILE),
                array(),
                WPFD_VERSION
            );
            wp_enqueue_script(
                'wpfd-colorboxjs',
                plugins_url('app/site/assets/js/jquery.colorbox-min.js', WPFD_PLUGIN_FILE),
                array(),
                WPFD_VERSION
            );
            wp_enqueue_script(
                'wpfd-colorbox-init',
                plugins_url('app/site/assets/js/colorbox.init.js', WPFD_PLUGIN_FILE),
                array(),
                WPFD_VERSION
            );
            wp_localize_script('wpfd-colorbox-init', 'wpfdcolorbox', array('wpfdajaxurl' => $this->ajaxUrl));
        }
    }
}
