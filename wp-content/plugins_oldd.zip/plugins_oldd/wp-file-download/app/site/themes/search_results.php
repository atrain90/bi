<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0.3
 */

use Joomunited\WPFramework\v1_0_4\Utilities;
use Joomunited\WPFramework\v1_0_4\Application;

$app = Application::getInstance('Wpfd');
if (!isset($config)) {
    $config = null;
}
if (!isset($ordering)) {
    $ordering = 'type';
}
if (!isset($dir)) {
    $dir = 'asc';
}
if (!isset($files)) {
    $files = null;
}
if (!isset($args)) {
    $args = array();
}
$ggviewer_tab = WpfdBase::loadValue($config, 'use_google_viewer', 'tab') === 'tab';
$ggviewer_lightbox = WpfdBase::loadValue($config, 'use_google_viewer', 'lightbox') === 'lightbox';
?>
<?php if ($files !== null && is_array($files) && count($files) > 0) : ?>
    <table class="table">
        <thead>
        <th>
            <a href="#" class="orderingCol <?php echo esc_attr(($ordering === 'type') ? 'curentOrderingCol' : ''); ?>"
               data-ordering="type"
               data-direction="<?php echo esc_attr(($ordering === 'type' && $dir === 'asc') ? 'desc' : 'asc'); ?>">
                <?php esc_html_e('File type', 'wpfd'); ?>
            </a>/
            <a href="#" class="orderingCol <?php echo esc_attr(($ordering === 'title') ? 'curentOrderingCol' : ''); ?>"
               data-ordering="title"
               data-direction="<?php echo esc_attr(($ordering === 'title' && $dir === 'asc') ? 'desc' : 'asc'); ?>">
                <?php esc_html_e('File name', 'wpfd'); ?>
            </a>
        </th>
        <?php if (WpfdBase::loadValue($config, 'use_google_viewer', 'lightbox') !== 'no') : ?>
            <th><?php esc_html_e('Open', 'wpfd'); ?></th>
        <?php endif; ?>
        <th>
            <a href="#" class="orderingCol <?php echo esc_attr(($ordering === 'created') ? 'curentOrderingCol' : ''); ?>"
               data-ordering="created"
               data-direction="<?php echo esc_attr(($ordering === 'created' && $dir === 'asc') ? 'desc' : 'asc'); ?>">
                <?php esc_html_e('Creation date', 'wpfd'); ?>
            </a>
        </th>
        <th>
            <a href="#" class="orderingCol <?php echo esc_attr(($ordering === 'cat') ? 'curentOrderingCol' : ''); ?>"
               data-ordering="cat"
               data-direction="<?php echo esc_attr(($ordering === 'cat' && $dir === 'asc') ? 'desc' : 'asc'); ?>">
                <?php esc_html_e('Category', 'wpfd'); ?>
            </a>
        </th>
        </thead>
        <tbody>

        <?php foreach ($files as $key => $file) : ?>
            <tr>
                <td class="title">
                    <span class="file-icon">
                    <?php if ($config['custom_icon'] && $file->file_custom_icon) : ?>
                        <img class="icon-custom" src="<?php echo esc_url(get_site_url() . $file->file_custom_icon); ?>">
                    <?php else : ?>
                        <i class="<?php echo esc_attr($file->ext); ?>"></i>
                    <?php endif; ?>
                    </span>
                    <a class="file-item wpfd-file-link" data-id="<?php echo esc_attr($file->ID); ?>"
                       href="<?php echo esc_url($file->linkdownload); ?>" id="file-<?php echo esc_attr($file->ID); ?>"
                       title="<?php echo esc_attr($file->title); ?>">
                        <?php
                        if (isset($file->crop_title)) {
                            echo esc_html($file->crop_title);
                        } else {
                            echo esc_html($file->title);
                        }
                        ?>
                    </a>
                </td>
                <?php if (WpfdBase::loadValue($config, 'use_google_viewer', 'lightbox') !== 'no') : ?>
                    <td class="viewer">
                        <?php if (isset($file->openpdflink)) { ?>
                            <a href="<?php echo esc_url($file->openpdflink); ?>" class="openlink" target="_blank">
                                <img src="<?php echo esc_url($app->getBaseUrl()); ?>/app/site/assets/images/open_242.png"
                                     title="<?php esc_html_e('Open', 'wpfd'); ?>"/></a>
                        <?php } elseif ($file->viewerlink) { ?>
                            <a data-id="<?php echo esc_attr($file->ID); ?>" data-catid="<?php echo esc_attr($file->catid); ?>"
                               data-file-type="<?php echo esc_attr($file->ext); ?>"
                               class="openlink <?php echo esc_attr(($ggviewer_lightbox) ? 'wpfdlightbox' : ''); ?>"
                                <?php echo esc_attr(($ggviewer_tab) ? 'target="_blank"' : ''); ?>
                               href='<?php echo esc_url($file->viewerlink); ?>'>
                                <img src="<?php echo esc_url($app->getBaseUrl()); ?>/app/site/assets/images/open_242.png"
                                     title="<?php esc_html_e('Open', 'wpfd'); ?>"/>
                            </a>
                        <?php } ?>
                    </td>
                <?php endif; ?>
                <td class="created"><?php echo esc_html($file->created); ?></td>
                <td class="catname"><?php echo esc_html($file->cattitle); ?></td>
            </tr>
        <?php endforeach; ?>

        </tbody>
    </table>
    <?php
    $limit = Utilities::getInput('limit', 'GET', 'string');
    $limit = ($limit === '') ? $args['file_per_page'] : $limit;
    wpfd_num($limit)
    ?>
<?php else : ?>
    <h5 class="text-center">
        <?php esc_html_e("Sorry, we haven't found anything that matches this search query", 'wpfd'); ?>
    </h5>
    <?php
endif; ?>
<?php // phpcs:ignore WordPress.WP.EnqueuedResources.NonEnqueuedScript -- This return in ajax request ?>
<script type="text/javascript" src="<?php echo esc_url($app->getBaseUrl()); ?>/app/site/assets/js/colorbox.init.js"></script>
