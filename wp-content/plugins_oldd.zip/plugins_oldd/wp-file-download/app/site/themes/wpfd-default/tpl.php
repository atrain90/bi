<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */


//-- No direct access
defined('ABSPATH') || die();

if (empty($this->files)) {
    $display_download = 'display-download-category';
} else {
    $display_download = '';
}

$showsubcategories   = (int) WpfdBase::loadValue($this->params, 'showsubcategories', 1) === 1 ? 'foldertree-hide' : '';
$showfoldertree      = (int) WpfdBase::loadValue($this->params, 'showfoldertree', 0) === 1;
$showcategorytitle   = (int) WpfdBase::loadValue($this->params, 'showcategorytitle', 1) === 1;
$showsubcategoriesck = (int) WpfdBase::loadValue($this->params, 'showsubcategories', 1) === 1;
$showdatemodified    = (int) WpfdBase::loadValue($this->params, 'showdatemodified', 0) === 1;

?>
<?php if ((int) WpfdBase::loadValue($this->params, 'showsubcategories', 1) === 1) : ?>
    <script type="text/x-handlebars-template" id="wpfd-template-categories">
        <div class="wpfd-categories">
            {{#if category}}
            {{#with category}}
            <h2>
                <?php if ((int) WpfdBase::loadValue($this->params, 'showcategorytitle', 1) === 1) : ?>
                    {{name}}
                <?php endif; ?>
                {{#if parent}}
                <a class="catlink wpfdcategory backcategory" href="#" data-idcat="{{parent}}">
                    <i class="zmdi zmdi-chevron-left"></i><?php esc_html_e('Back', 'wpfd'); ?></a>
                {{/if}}
            </h2>
            {{/with}}
            {{/if}}

            {{#if categories}}
            {{#each categories}}
            <a class="catlink wpfdcategory" style="<?php echo esc_html($this->style); ?>" href="#"
               data-idcat="{{term_id}}"><span>{{name}}</span>
                <i class="zmdi zmdi-folder wpfd-folder"></i>
            </a>
            {{/each}}
            {{/if}}
        </div>
    </script>
<?php endif; ?>

    <script type="text/x-handlebars-template" id="wpfd-template-files">
        {{#if files}}
        <div class="wpfd_list">
            {{#each files}}
            <div class="file" style="<?php echo esc_html($this->style); ?>" data-id="{{ID}}" data-catid="{{catid}}">
                <div class="filecontent">
                    <?php if ($this->config['custom_icon']) : ?>
                        {{#if file_custom_icon}}
                        <div class="icon-custom"><img src="{{file_custom_icon}}"></div>
                        {{else}}
                        <div class="ext {{ext}}"><span class="txt">{{ext}}</div>
                        {{/if}}
                    <?php else : ?>
                        <div class="ext {{ext}}"><span class="txt">{{ext}}</div>
                    <?php endif; ?>

                    <?php if ((int) WpfdBase::loadValue($this->params, 'showtitle', 1) === 1) : ?>
                        <h3><a href="{{linkdownload}}" class="wpfd_downloadlink"
                               title="{{post_title}}">{{crop_title}}</a></h3>
                    <?php endif; ?>
                    <div class="file-xinfo">
                        <div class="file-desc">{{{description}}}</div>
                        <?php if ((int) WpfdBase::loadValue($this->params, 'showversion', 1) === 1) : ?>
                            {{#if versionNumber}}
                            <div class="file-version">
                                <span><?php esc_html_e('Version :', 'wpfd'); ?></span> {{versionNumber}}&nbsp;
                            </div>
                            {{/if}}
                        <?php endif; ?>
                        <?php if ((int) WpfdBase::loadValue($this->params, 'showsize', 1) === 1) : ?>
                            <div class="file-size"><span><?php esc_html_e('Size :', 'wpfd'); ?></span> {{bytesToSize size}}
                            </div>
                        <?php endif; ?>
                        <?php if ((int) WpfdBase::loadValue($this->params, 'showhits', 1) === 1) : ?>
                            <div class="file-hits"><span><?php esc_html_e('Hits :', 'wpfd'); ?></span> {{hits}}</div>
                        <?php endif; ?>
                        <?php if ((int) WpfdBase::loadValue($this->params, 'showdateadd', 0) === 1) : ?>
                            <div class="file-dated"><span><?php esc_html_e('Date added :', 'wpfd'); ?></span> {{created}}</div>
                        <?php endif; ?>
                        <?php if ((int) WpfdBase::loadValue($this->params, 'showdatemodified', 0) === 1) : ?>
                            <div class="file-modifed"><span><?php esc_html_e('Date modified :', 'wpfd'); ?></span> {{modified}}
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                <span class="file-right">
                        <?php if ((int) WpfdBase::loadValue($this->params, 'showdownload', 1) === 1) : ?>
                            <?php
                            $bg_download    = WpfdBase::loadValue($this->params, 'bgdownloadlink', '');
                            $color_download = WpfdBase::loadValue($this->params, 'colordownloadlink', '');
                            $download_style = '';
                            if ($bg_download !== '') {
                                $download_style .= 'background-color:' . $bg_download . ';';
                            }
                            if ($color_download !== '') {
                                $download_style .= 'color:' . $color_download . ';';
                            }
                            ?>

                            <a class="downloadlink wpfd_downloadlink"
                               href="{{linkdownload}}" style="<?php echo esc_html($download_style); ?>"><?php esc_html_e('Download', 'wpfd'); ?><i
                                        class="zmdi zmdi-cloud-download wpfd-download"></i></a>
                        <?php endif; ?>
                    {{#if openpdflink}}
                            <a href="{{openpdflink}}" target="_blank"><?php esc_html_e('Preview', 'wpfd'); ?><i
                                        class="zmdi zmdi-filter-center-focus wpfd-preview"></i></a>
                        {{else}}
                            {{#if viewerlink}}
                    <?php
                    $viewer_attr = 'openlink wpfdlightbox wpfd_previewlink';
                    $target = '';
                    if ((string) $this->config['use_google_viewer'] === 'tab') {
                        $viewer_attr = 'openlink wpfd_previewlink';
                        $target = '_blank';
                    } ?>
                    <a href="{{viewerlink}}" class="<?php echo esc_attr($viewer_attr); ?>" target="<?php echo esc_attr($target); ?>" data-id="{{ID}}" data-catid="{{catid}}"
                       data-file-type="{{ext}}"><?php esc_html_e('Preview', 'wpfd'); ?><i
                                class="zmdi zmdi-filter-center-focus wpfd-preview"></i></a>
                            {{/if}}
                        {{/if}}

                        </span>
            </div>
            {{/each}}
        </div>
        {{/if}}
    </script>
<?php if (!empty($this->category)) : ?>
    <?php if (!empty($this->files) || !empty($this->categories)) : ?>
        <div class="wpfd-content wpfd-content-default wpfd-content-multi"
             data-category="<?php echo esc_attr($this->category->term_id); ?>">
            <input type="hidden" id="current_category" value="<?php echo esc_attr($this->category->term_id); ?>"/>
            <input type="hidden" id="current_category_slug" value="<?php echo esc_attr($this->category->slug); ?>"/>
            <?php if ((int) WpfdBase::loadValue($this->params, 'showbreadcrumb', 1) === 1 && !$this->latest) : ?>
                <ul class="breadcrumbs wpfd-breadcrumbs-default head-category-default">
                    <li class="active">
                        <?php echo esc_html($this->category->name); ?>
                    </li>
                    <?php if ($this->config['download_category'] && !$this->categoryFrom) : ?>
                        <a data-catid=""
                           class="default-download-category <?php echo esc_attr($display_download); ?>"
                           href="<?php echo esc_url($this->category->linkdownload_cat); ?> ">
                            <?php esc_html_e('Download all ', 'wpfd'); ?>
                            <i class="zmdi zmdi-check-all wpfd-download-category"></i>
                        </a>
                    <?php endif; ?>
                </ul>
            <?php elseif ($this->config['download_category'] && !$this->categoryFrom && !$this->latest) : ?>
                <ul class="head-category-default">
                    <li>
                        &nbsp;
                    </li>
                    <?php if ($this->config['download_category'] && !$this->categoryFrom) : ?>
                        <a data-catid=""
                           class="default-download-category <?php echo esc_attr($display_download); ?>"
                           href="<?php echo esc_url($this->category->linkdownload_cat); ?> ">
                            <?php esc_html_e('Download all ', 'wpfd'); ?>
                            <i class="zmdi zmdi-check-all wpfd-download-category"></i>
                        </a>
                    <?php endif; ?>
                </ul>
            <?php endif; ?>
            <div class="wpfd-container">
                <div class="wpfd-flex-container">
                    <?php if ((int) WpfdBase::loadValue($this->params, 'showfoldertree', 0) === 1 && !$this->latest) : ?>
                        <div class="wpfd-foldertree wpfd-foldertree-default <?php echo esc_attr($showsubcategories); ?>">
                        </div>
                    <?php endif; ?>

                    <div class="wpfd-container-default <?php echo esc_attr($showfoldertree ? ' with_foldertree' : ''); ?>">
                        <div class="wpfd-categories">
                            <?php if ($showcategorytitle && !$this->latest) : ?>
                                <h2><?php echo esc_html($this->category->name); ?></h2>
                            <?php endif; ?>
                            <?php if (is_countable($this->categories) && count($this->categories) && $showsubcategoriesck && !$this->latest) : ?>
                                <?php foreach ($this->categories as $category) : ?>
                                    <a class="wpfdcategory catlink" style="<?php echo esc_html($this->style); ?>" href="#"
                                       data-idcat="<?php echo esc_attr($category->term_id); ?>"
                                       title="<?php echo esc_html($category->name); ?>">
                                        <span><?php echo esc_html($category->name); ?></span>
                                        <i class="zmdi zmdi-folder wpfd-folder"></i>
                                    </a>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                        <?php if (!empty($this->files)) : ?>
                            <div class="wpfd_list">
                                <?php foreach ($this->files as $file) : ?>
                                    <div class="file" style="<?php echo esc_html($this->style); ?>"
                                         data-id="<?php echo esc_attr($file->ID); ?>"
                                         data-catid="<?php echo esc_attr($file->catid); ?>">
                                        <div class="filecontent">
                                            <?php if ($this->config['custom_icon'] && $file->file_custom_icon) : ?>
                                                <div class="icon-custom"><img
                                                            src="<?php echo esc_url($file->file_custom_icon); ?>">
                                                </div>
                                            <?php else : ?>
                                                <div class="ext <?php echo esc_attr(strtolower($file->ext)); ?>"><span
                                                            class="txt"><?php echo esc_html($file->ext); ?></div>
                                            <?php endif; ?>
                                            <?php if ((int) WpfdBase::loadValue($this->params, 'showtitle', 1) === 1) : ?>
                                                <h3><a class="wpfd_downloadlink"
                                                       href="<?php echo esc_url($file->linkdownload) ?>"
                                                       title="<?php echo esc_html($file->post_title); ?>">
                                                        <?php echo esc_html($file->crop_title); ?>
                                                    </a>
                                                </h3>
                                            <?php endif; ?>
                                            <div class="file-xinfo">
                                                <div class="file-desc">
                                                    <?php
                                                    if (!empty($file->description)) {
                                                        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- Used wpfd_esc_desc to remove <script>
                                                        echo wpfd_esc_desc($file->description);
                                                    }
                                                    ?>
                                                </div>
                                                <?php if ((int) WpfdBase::loadValue($this->params, 'showversion', 1) === 1 &&
                                                    trim($file->versionNumber !== '')) : ?>
                                                    <div class="file-version">
                                                        <span><?php esc_html_e('Version :', 'wpfd'); ?></span>
                                                        <?php echo esc_html($file->versionNumber); ?>&nbsp;
                                                    </div>
                                                <?php endif; ?>
                                                <?php if ((int) WpfdBase::loadValue($this->params, 'showsize', 1) === 1) : ?>
                                                    <div class="file-size">
                                                        <span><?php esc_html_e('Size :', 'wpfd'); ?></span>
                                                        <?php $fileSize = ($file->size === 'n/a') ?
                                                            $file->size : WpfdHelperFile::bytesToSize($file->size);
                                                            echo esc_html($fileSize);
                                                        ?>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if ((int) WpfdBase::loadValue($this->params, 'showhits', 1) === 1) : ?>
                                                    <div class="file-hits">
                                                        <span><?php esc_html_e('Hits :', 'wpfd'); ?></span>
                                                        <?php echo esc_html($file->hits); ?>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if ((int) WpfdBase::loadValue($this->params, 'showdateadd', 0) === 1) : ?>
                                                    <div class="file-dated">
                                                        <span><?php esc_html_e('Date added :', 'wpfd'); ?></span>
                                                        <?php echo esc_html($file->created); ?>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if ($showdatemodified) : ?>
                                                    <div class="file-modified">
                                                        <span><?php esc_html_e('Date modified :', 'wpfd'); ?></span>
                                                        <?php echo esc_html($file->modified); ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        <div class="file-right">
                                            <?php if ((int) WpfdBase::loadValue($this->params, 'showdownload', 1) === 1) : ?>
                                                <?php
                                                $bg_download = WpfdBase::loadValue($this->params, 'bgdownloadlink', '');
                                                $color_download = WpfdBase::loadValue(
                                                    $this->params,
                                                    'colordownloadlink',
                                                    ''
                                                );
                                                $download_style = '';
                                                if ($bg_download !== '') {
                                                    $download_style .= 'background-color:' . $bg_download . ';';
                                                }
                                                if ($color_download !== '') {
                                                    $download_style .= 'color:' . $color_download . ';';
                                                }
                                                ?>
                                                <a class="downloadlink wpfd_downloadlink"
                                                   href="<?php echo esc_url($file->linkdownload) ?>" style="<?php echo esc_html($download_style); ?>">
                                                    <?php esc_html_e('Download', 'wpfd'); ?>
                                                    <i class="zmdi zmdi-cloud-download wpfd-download"></i>
                                                </a>
                                            <?php endif; ?>
                                            <?php if (isset($file->openpdflink)) { ?>
                                                <a href="<?php echo esc_url($file->openpdflink); ?>" class="openlink"
                                                   target="_blank">
                                                    <?php esc_html_e('Preview', 'wpfd'); ?>
                                                    <i class="zmdi zmdi-filter-center-focus wpfd-preview"></i>
                                                </a>
                                            <?php } else { ?>
                                                <?php if (isset($file->viewerlink)) { ?>
                                                    <?php
                                                    $viewer_attr = 'openlink wpfdlightbox wpfd_previewlink';
                                                    $target = '';
                                                    if ($file->viewer_type === 'tab') {
                                                        $viewer_attr = 'openlink wpfd_previewlink';
                                                        $target = '_blank';
                                                    } ?>
                                                    <a href="<?php echo esc_url($file->viewerlink); ?>" class="<?php echo esc_html($viewer_attr); ?>"
                                                       target="<?php echo esc_attr($target); ?>"
                                                       data-id="<?php echo esc_attr($file->ID); ?>"
                                                       data-catid="<?php echo esc_attr($file->catid); ?>"
                                                       data-file-type="<?php echo esc_attr(strtolower($file->ext)); ?>">
                                                        <?php esc_html_e('Preview', 'wpfd'); ?>
                                                        <i class="zmdi zmdi-filter-center-focus wpfd-preview"></i>
                                                    </a>
                                                <?php } ?>
                                            <?php } ?>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php endif; ?>

