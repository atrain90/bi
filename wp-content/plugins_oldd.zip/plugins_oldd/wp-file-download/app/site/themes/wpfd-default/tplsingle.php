<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

//-- No direct access
defined('ABSPATH') || die();
?>
<?php if (!empty($this->file)) : ?>
    <?php
    $bg_color    = WpfdBase::loadValue($this->file_params, 'singlebg', '#444444');
    $hover_color = WpfdBase::loadValue($this->file_params, 'singlehover', '#888888');
    $font_color  = WpfdBase::loadValue($this->file_params, 'singlefontcolor', '#ffffff');
    $showsize    = ((int)WpfdBase::loadValue($this->params, 'showsize', 1) === 1) ? true : false;

    if ($this->name_display) {
        $name_display = $this->name_display;
    } else {
        $name_display = $this->file->title;
    }
    ?>
    <style>
        .wpfd-single-file .wpfd_previewlink {
            margin-top: 10px;
            display: block;
            font-weight: bold;
        }

        <?php if ($bg_color !== '') {?>
        .wpfd-single-file .wpfd-file-link {
            background-color: <?php echo esc_html($bg_color);?> !important;
        }

        <?php } ?>
        <?php if ($font_color !== '') {?>
        .wpfd-single-file .wpfd-file-link a {
            color: <?php echo esc_html($font_color);?> !important;
        }

        <?php } ?>
        <?php if ($hover_color !== '') { ?>
        .wpfd-single-file .wpfd-file-link a:hover {
            background-color: <?php echo esc_html($hover_color);?> !important;
        }

        <?php } ?>
    </style>

    <div class="wpfd-file wpfd-single-file" data-file="<?php echo esc_attr($this->file->ID); ?>">
        <div class="wpfd-file-link wpfd_downloadlink">
            <a class="noLightbox"
               href="<?php echo esc_url($this->file->linkdownload) ?>"
               data-id="<?php echo esc_attr($this->file->ID); ?>"
                <?php
                $title = isset($this->file->description) ? wp_strip_all_tags($this->file->description) : $this->file->title;
                ?>
               title="<?php echo esc_html($title); ?>">
                <span class="droptitle">
                    <?php echo esc_html($name_display); ?>
                </span>
                <br/>
                <span class="dropinfos">
                    <?php if ($showsize) : ?>
                        <b><?php esc_html_e('Size', 'wpfd'); ?>: </b>
                        <?php echo esc_html(WpfdHelperFile::bytesToSize($this->file->size)); ?>
                    <?php endif; ?>
                    <b><?php esc_html_e('Format', 'wpfd'); ?> : </b>
                    <?php echo esc_html(strtoupper($this->file->ext)); ?>
                </span>
            </a><br>
            <?php if (isset($this->file->openpdflink)) { ?>
                <a href="<?php echo esc_url($this->file->openpdflink); ?>" class="noLightbox" target="_blank">
                    <?php esc_html_e('Preview', 'wpfd'); ?> </a>
            <?php } elseif (isset($this->file->viewerlink)) { ?>
                <a data-id="<?php echo esc_attr($this->file->ID); ?>" data-catid="<?php echo esc_attr($this->file->catid); ?>"
                   data-file-type="<?php echo esc_attr($this->file->ext); ?>"
                   class="openlink wpfdlightbox wpfd_previewlink noLightbox"
                   href="<?php echo esc_url($this->file->viewerlink); ?>">
                    <?php esc_html_e('Preview', 'wpfd'); ?></a>
            <?php } ?>
        </div>
    </div>
<?php endif; ?>
