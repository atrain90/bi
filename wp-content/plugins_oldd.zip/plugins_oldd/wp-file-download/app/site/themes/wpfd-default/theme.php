<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

//-- No direct access
defined('ABSPATH') || die();

/**
 * Class WpfdThemeDefault
 */
class WpfdThemeDefault
{
    /**
     * Theme name
     *
     * @var string
     */
    public $name = 'default';

    /**
     * Ajax url
     *
     * @var string
     */
    private $ajaxUrl = '';

    /**
     * Plugin path
     *
     * @var string
     */
    private $path = '';

    /**
     * Config
     *
     * @var array
     */

    private $config = array();

    /**
     * Options
     *
     * @var array
     */
    protected $options;

    /**
     * Get theme name
     *
     * @return string
     */
    public function getThemeName()
    {
        return $this->name;
    }

    /**
     * Set ajax url
     *
     * @param string $url Ajaxurl
     *
     * @return void
     */
    public function setAjaxUrl($url)
    {
        $this->ajaxUrl = $url;
    }

    /**
     * Set path
     *
     * @param string $path Plugin path
     *
     * @return void
     */
    public function setPath($path)
    {
        $this->path = $path;
    }

    /**
     * Set config
     *
     * @param array $config Configs
     *
     * @return void
     */
    public function setConfig($config)
    {
        $this->config = $config;
    }

    /**
     * Show category
     *
     * @param array $options Options
     *
     * @return mixed|string
     */
    public function showCategory($options)
    {
        if (empty($options['files']) && empty($options['categories'])) {
            return '';
        }
        $this->options = $options;

        // Load css and scripts
        $this->loadAssets();
        $this->loadLightboxAssets();

        $content            = '';
        $this->files        = $this->options['files'];
        $this->category     = $this->options['category'];
        $this->categoryFrom = apply_filters('wpfdAddonCategoryFrom', $this->category->term_id);
        if ((int) $this->categoryFrom === (int) $this->category->term_id) {
            $this->categoryFrom = false;
        }
        $this->categories = $this->options['categories'];
        $this->params     = $this->options['params'];
        $this->latest     = false;
        if (isset($this->options['latest'])) {
            $this->latest = $this->options['latest'];
        }

        if (!empty($this->options['files']) || (int) WpfdBase::loadValue($this->params, 'showsubcategories', 1) === 1 ||
            WpfdBase::loadValue($this->params, 'showfoldertree', 0)
        ) {
            $style = 'margin : ' . WpfdBase::loadValue($this->params, 'margintop', 5) . 'px ';
            $style .= WpfdBase::loadValue($this->params, 'marginright', 5) . 'px ';
            $style .= WpfdBase::loadValue($this->params, 'marginbottom', 5) . 'px ';
            $style .= WpfdBase::loadValue($this->params, 'marginleft', 5) . 'px;';
            $this->style = $style;
            ob_start();
            require dirname(__FILE__) . DIRECTORY_SEPARATOR . 'tpl.php';
            $content = ob_get_contents();
            ob_end_clean();
            // Fix conflict with wpautop in VC
            $content = str_replace(array("\n", "\r"), '', $content);
        }

        return $content;
    }

    /**
     * Display file
     *
     * @param array $options Option
     *
     * @return mixed|string
     */
    public function showFile($options)
    {
        $this->options = $options;
        if (empty($this->options['file'])) {
            return '';
        }
        // Load css and scripts
        $this->loadAssets(true);
        $this->loadLightboxAssets();

        $this->file         = $this->options['file'];
        $this->params       = $this->options['params'];
        $this->file_params  = $this->options['file_params'];
        $this->name_display = $this->options['name'];

        $style       = 'margin: ' . WpfdBase::loadValue($this->params, 'margintop', 5) . 'px ';
        $style       .= WpfdBase::loadValue($this->params, 'marginright', 5) . 'px ';
        $style       .= WpfdBase::loadValue($this->params, 'marginbottom', 5) . 'px ';
        $style       .= WpfdBase::loadValue($this->params, 'marginleft', 5) . 'px;';
        $this->style = $style;

        $tplSinglePath       = dirname(__FILE__) . DIRECTORY_SEPARATOR . 'tplsingle.php';
        $wpUploadsPath       = wp_upload_dir();
        $customTplSinglePath = $wpUploadsPath['basedir'] . DIRECTORY_SEPARATOR . 'wpfd-themes';
        $customTplSinglePath .= DIRECTORY_SEPARATOR . 'tplsingle.php';
        if (file_exists($customTplSinglePath)) {
            $tplSinglePath = $customTplSinglePath;
        }

        ob_start();
        require $tplSinglePath;
        $content = ob_get_contents();
        ob_end_clean();

        // Fix conflict with wpautop in VC
        $content = str_replace(array("\n", "\r"), '', $content);


        return $content;
    }

    /**
     * Load theme styles and scripts
     *
     * @param boolean $single Load for single file
     *
     * @return void
     */
    private function loadAssets($single = false)
    {
        if (WpfdBase::checkExistTheme($this->name)) {
            $url = plugin_dir_url(__FILE__);
        } else {
            $dirs = wp_get_upload_dir();
            $url = $dirs['baseurl'] . '/wpfd-themes/wpfd-' . $this->name . '/';
        }

        wp_enqueue_script('jquery');
        wp_enqueue_script('handlebars', $url . 'js/handlebars-1.0.0-rc.3.js');
        wp_enqueue_script(
            'wpfd-front',
            plugins_url('app/site/assets/js/front.js', WPFD_PLUGIN_FILE),
            array(),
            WPFD_VERSION
        );


        if (!$single) {
            wp_enqueue_style(
                'wpfd-material-design',
                plugins_url('app/site/assets/css/material-design-iconic-font.min.css', WPFD_PLUGIN_FILE),
                array(),
                WPFD_VERSION
            );
            wp_enqueue_script(
                'wpfd-foldertree',
                plugins_url('app/site/assets/js/jaofiletree.js', WPFD_PLUGIN_FILE),
                array(),
                WPFD_VERSION
            );
            wp_enqueue_style(
                'wpfd-foldertree',
                plugins_url('app/site/assets/css/jaofiletree.css', WPFD_PLUGIN_FILE),
                array(),
                WPFD_VERSION
            );
            $path_foobar = $this->path . DIRECTORY_SEPARATOR . 'site' . DIRECTORY_SEPARATOR . 'foobar';
            wp_enqueue_script('wpfd-helper', plugins_url('assets/js/helper.js', $path_foobar));
        }

        wp_enqueue_style('wpfd-theme-default', $url . 'css/style.css', array(), WPFD_VERSION);
        wp_enqueue_script('wpfd-theme-default', $url . 'js/script.js', array(), WPFD_VERSION);
        wp_localize_script('wpfd-theme-default', 'wpfdparams', array(
            'wpfdajaxurl'          => $this->ajaxUrl,
            'ga_download_tracking' => $this->config['ga_download_tracking'],
            'ajaxadminurl'         => admin_url('admin-ajax.php') . '?juwpfisadmin=0'
        ));
    }

    /**
     * Load Lightbox style and scripts
     *
     * @return void
     */
    private function loadLightboxAssets()
    {
        if ($this->config['use_google_viewer'] === 'lightbox') {
            wp_enqueue_style(
                'wpfd-videojs',
                plugins_url('app/site/assets/css/video-js.css', WPFD_PLUGIN_FILE),
                array(),
                WPFD_VERSION
            );
            wp_enqueue_style(
                'wpfd-colorbox',
                plugins_url('app/site/assets/css/colorbox.css', WPFD_PLUGIN_FILE),
                array(),
                WPFD_VERSION
            );
            wp_enqueue_style(
                'wpfd-viewer',
                plugins_url('app/site/assets/css/viewer.css', WPFD_PLUGIN_FILE),
                array(),
                WPFD_VERSION
            );
            wp_enqueue_script(
                'wpfd-colorboxjs',
                plugins_url('app/site/assets/js/jquery.colorbox-min.js', WPFD_PLUGIN_FILE),
                array(),
                WPFD_VERSION
            );
            wp_enqueue_script(
                'wpfd-colorbox-init',
                plugins_url('app/site/assets/js/colorbox.init.js', WPFD_PLUGIN_FILE),
                array(),
                WPFD_VERSION
            );
            wp_enqueue_script(
                'wpfd-videojs',
                plugins_url('app/site/assets/js/video.js', WPFD_PLUGIN_FILE),
                array(),
                WPFD_VERSION
            );
            wp_localize_script(
                'wpfd-colorbox-init',
                'wpfdcolorbox',
                array('wpfdajaxurl' => $this->ajaxUrl)
            );
        }
    }
}
