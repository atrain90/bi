<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

use Joomunited\WPFramework\v1_0_4\Controller;
use Joomunited\WPFramework\v1_0_4\Form;
use Joomunited\WPFramework\v1_0_4\Utilities;
use Joomunited\WPFramework\v1_0_4\Application;

defined('ABSPATH') || die();

/**
 * Class WpfdControllerConfig
 */
class WpfdControllerConfig extends Controller
{
    /**
     * Set theme setting
     *
     * @return void
     */
    public function savetheme()
    {
        $model = $this->getModel();
        $themes = $model->getThemes();
        $theme = Utilities::getInput('selecttheme', 'POST');
        if (!in_array($theme, $themes)) {
            $this->redirect('admin.php?page=wpfd-config&error=1');
        }
        if (!$model->savetheme($theme)) {
            $this->redirect('admin.php?page=wpfd-config&error=2');
        }
        $this->redirect('admin.php?page=wpfd-config&msg=' . esc_html__('success', 'wpfd'));
    }

    /**
     * Save theme params
     *
     * @return void
     */
    public function savethemeparams()
    {
        $model = $this->getModel();
        $theme = Utilities::getInput('theme', 'GET', 'none');
        if ((string)$theme === '') {
            $theme = 'default';
        }
        $form = new Form();
        if (WpfdBase::checkExistTheme($theme)) {
            $formfile = Application::getInstance('Wpfd')->getPath() . DIRECTORY_SEPARATOR . 'site';
            $formfile .= DIRECTORY_SEPARATOR . 'themes' . DIRECTORY_SEPARATOR . 'wpfd-' . $theme;
            $formfile .= DIRECTORY_SEPARATOR . 'form.xml';
        } else {
            $dir = wp_upload_dir();
            $formfile = $dir['basedir'] . '/wpfd-themes/wpfd-' . $theme . DIRECTORY_SEPARATOR . 'form.xml';
        }
        if (!$form->load($formfile)) {
            $this->redirect('admin.php?page=wpfd-config&error=1');
        }
        if (!$form->validate()) {
            $this->redirect('admin.php?page=wpfd-config&error=2');
        }
        $datas = $form->sanitize();
        if (!$model->saveThemeParams($theme, $datas)) {
            $this->redirect('admin.php?page=wpfd-config&error=3');
        }
        $this->redirect('admin.php?page=wpfd-config&msg=' . esc_html__('success', 'wpfd'));
    }

    /**
     * Clone a theme
     *
     * @return void
     */
    public function clonetheme()
    {
        $model = $this->getModel();
        $form = new Form();
        $formfile = Application::getInstance('Wpfd')->getPath() . DIRECTORY_SEPARATOR . 'admin' . DIRECTORY_SEPARATOR;
        $formfile .= 'forms' . DIRECTORY_SEPARATOR . 'clone.xml';
        if (!$form->load($formfile)) {
            $this->redirect('admin.php?page=wpfd-config&error=1');
        }
        if (!$form->validate()) {
            $this->redirect('admin.php?page=wpfd-config&error=2');
        }
        $datas = $form->sanitize();

        if (isset($datas['theme_name']) && ($datas['theme_name'] === '')) {
            $this->redirect('admin.php?page=wpfd-config&msg=' . esc_html__('Please, Enter theme name', 'wpfd'));
        }
        if (!$model->clonetheme($datas)) {
            $this->redirect('admin.php?page=wpfd-config&error=3');
        } else {
            $this->redirect('admin.php?page=wpfd-config&msg=' . esc_html__('Clone theme successfully', 'wpfd'));
        }
        $this->redirect('admin.php?page=wpfd-config&msg=' . esc_html__('success', 'wpfd'));
    }

    /**
     * Save file params
     *
     * @return void
     */
    public function savetfileparams()
    {
        $model = $this->getModel();

        $form = new Form();
        $formfile = Application::getInstance('Wpfd')->getPath() . DIRECTORY_SEPARATOR . 'admin' . DIRECTORY_SEPARATOR;
        $formfile .= 'forms' . DIRECTORY_SEPARATOR . 'file_config.xml';
        if (!$form->load($formfile)) {
            $this->redirect('admin.php?page=wpfd-config&error=1');
        }
        if (!$form->validate()) {
            $this->redirect('admin.php?page=wpfd-config&error=2');
        }
        $datas = $form->sanitize();
        if (!$model->saveFileParams($datas)) {
            $this->redirect('admin.php?page=wpfd-config&error=3');
        }
        $this->redirect('admin.php?page=wpfd-config&msg=' . esc_html__('success', 'wpfd'));
    }

    /**
     * Save search params
     *
     * @return void
     */
    public function savesearchparams()
    {
        $model = $this->getModel();

        $form = new Form();
        $formfile = Application::getInstance('Wpfd')->getPath() . DIRECTORY_SEPARATOR . 'admin' . DIRECTORY_SEPARATOR;
        $formfile .= 'forms' . DIRECTORY_SEPARATOR . 'search.xml';
        if (!$form->load($formfile)) {
            $this->redirect('admin.php?page=wpfd-config&error=1');
        }
        if (!$form->validate()) {
            $this->redirect('admin.php?page=wpfd-config&error=2');
        }
        $datas = $form->sanitize();

        if (!$model->saveSearchParams($datas)) {
            $this->redirect('admin.php?page=wpfd-config&error=3');
        }
        $this->redirect('admin.php?page=wpfd-config&msg=' . esc_html__('success', 'wpfd'));
    }

    /**
     * Save config
     *
     * @return void
     */
    public function saveconfig()
    {
        $model = $this->getModel();

        $form = new Form();
        if (!$form->load('config')) {
            $this->redirect('admin.php?page=wpfd-config&error=1');
        }
        if (!$form->validate()) {
            $this->redirect('admin.php?page=wpfd-config&error=2');
        }
        $datas = $form->sanitize();
        if (!$model->save($datas)) {
            $this->redirect('admin.php?page=wpfd-config&error=3');
        }
        $this->redirect('admin.php?page=wpfd-config&msg=' . esc_html__('success', 'wpfd'));
    }


    /**
     * Save upload params
     *
     * @return void
     */
    public function saveuploadparams()
    {
        $model = $this->getModel();

        $form = new Form();
        $formfile = Application::getInstance('Wpfd')->getPath() . DIRECTORY_SEPARATOR . 'admin' . DIRECTORY_SEPARATOR;
        $formfile .= 'forms' . DIRECTORY_SEPARATOR . 'upload.xml';
        if (!$form->load($formfile)) {
            $this->redirect('admin.php?page=wpfd-config&error=1');
        }
        if (!$form->validate()) {
            $this->redirect('admin.php?page=wpfd-config&error=2');
        }
        $datas = $form->sanitize();
        if (!$model->saveUploadParams($datas)) {
            $this->redirect('admin.php?page=wpfd-config&error=3');
        }
        $this->redirect('admin.php?page=wpfd-config&msg=' . esc_html__('success', 'wpfd'));
    }

    /**
     * Save file in cate setting
     *
     * @return void
     */
    public function savefilecatparams()
    {
        $model = $this->getModel();

        $form = new Form();
        $formfile = Application::getInstance('Wpfd')->getPath() . DIRECTORY_SEPARATOR . 'admin' . DIRECTORY_SEPARATOR;
        $formfile .= 'forms' . DIRECTORY_SEPARATOR . 'file_cat_sortcode.xml';
        if (!$form->load($formfile)) {
            $this->redirect('admin.php?page=wpfd-config&error=1');
        }
        if (!$form->validate()) {
            $this->redirect('admin.php?page=wpfd-config&error=2');
        }
        $datas = $form->sanitize();
        if (!$model->saveFileInCatParams($datas)) {
            $this->redirect('admin.php?page=wpfd-config&error=3');
        }
        $this->redirect('admin.php?page=wpfd-config&msg=' . esc_html__('success', 'wpfd'));
    }

    /**
     * Get Token of Dropbox on authenticate
     *
     * @return void
     */
    public function getTokenKey()
    {
        $dropAuthor = Utilities::getInput('dropAuthor', 'POST', 'string');

        $app = Application::getInstance('WpfdAddon');
        $path_wpfdaddondropbox = $app->getPath() . DIRECTORY_SEPARATOR . $app->getType();
        $path_wpfdaddondropbox .= DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . 'WpfdAddonDropbox.php';
        require_once $path_wpfdaddondropbox;
        $dropbox = new WpfdAddonDropbox();

        if (!empty($dropAuthor)) {
            //convert code authorCOde to Token
            try {
                $list = $dropbox->convertAuthorizationCode($dropAuthor);
            } catch (Exception $ex) {
                $this->exitStatus(false, esc_html__('The Authorization Code are Wrong!', 'wpfd'));
            }
        } else {
            $this->exitStatus(false, esc_html__('The Authorization code could not be empty!', 'wpfd'));
        }
        if (!isset($list)) {
            $list = array();
        }
        if ($list['accessToken']) {
            $app = Application::getInstance('WpfdAddon');
            $path_wpfdhelper = $app->getPath() . DIRECTORY_SEPARATOR . 'admin' . DIRECTORY_SEPARATOR . 'helpers';
            $path_wpfdhelper .= DIRECTORY_SEPARATOR . 'WpfdHelper.php';
            require_once $path_wpfdhelper;
            //save accessToken to database
            $saveParams = new WpfdAddonHelper();
            $params = $saveParams->getAllDropboxConfigs();
            $params['dropboxToken'] = $list['accessToken'];
            $saveParams->saveDropboxConfigs($params);
        } else {
            $this->exitStatus(false, esc_html__('The Authorization Code are Wrong!', 'wpfd'));
        }
        $this->exitStatus(true, $list);
    }

    /**
     * Get all versions to delete
     *
     * @param boolean $return Return array or json
     *
     * @return array
     */
    public function prepareVersions($return = false)
    {
        global $wpdb;
        if (!wp_verify_nonce(Utilities::getInput('security', 'POST', 'none'), 'wpfd-security')) {
            wp_send_json(array('success' => false, 'message' => esc_html__('Wrong security code!', 'wpfd')));
        }

        $metas = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT DISTINCT pm.post_id, tt.term_id FROM ' . $wpdb->postmeta . ' AS pm
                 INNER JOIN ' . $wpdb->term_relationships . ' AS tr ON tr.object_id = pm.post_id
                 INNER JOIN ' . $wpdb->term_taxonomy . ' AS tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
                WHERE pm.meta_key = %s
                AND tt.taxonomy = %s',
                '_wpfd_file_versions',
                'wpfd-category'
            )
        );

        if (!$return) {
            $total = is_countable($metas) ? count($metas) : 0;
            if ($total > 0) {
                wp_send_json(array('success' => true, 'total' => $total));
            } else {
                wp_send_json(array('success' => false, 'message' => esc_html__('No versions to delete!', 'wpfd')));
            }
        } else {
            $files = array();
            if (!is_wp_error($metas) && !empty($metas)) {
                foreach ($metas as $meta) {
                    $files[] = array(
                        'id' => $meta->post_id,
                        'catId' => $meta->term_id
                    );
                }
            }

            return $files;
        }
    }

    /**
     * Delete all files versions
     *
     * @return void
     */
    public function purgeVersions()
    {
        if (!wp_verify_nonce(Utilities::getInput('security', 'POST', 'none'), 'wpfd-security')) {
            wp_send_json(array('success' => false, 'message' => esc_html__('Wrong security code!', 'wpfd')));
        }
        $keep = Utilities::getInt('keep');

        if ((int) $keep > 100) {
            $keep = 100;
        }

        $versions = $this->prepareVersions(true);

        if (is_array($versions) && !empty($versions)) {
            Application::getInstance('Wpfd');
            $fileModel = $this->getModel('file');
            foreach ($versions as $file) {
                $fileModel->deleteOldVersions($file['id'], $file['catId'], $keep);
            }
            wp_send_json(array('success' => true));
        } else {
            wp_send_json(array('success' => false, 'message' => esc_html__('No versions to delete!', 'wpfd')));
        }
    }
}
