<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

use Joomunited\WPFramework\v1_0_4\Controller;
use Joomunited\WPFramework\v1_0_4\Utilities;
use Joomunited\WPFramework\v1_0_4\Filesystem;

defined('ABSPATH') || die();

/**
 * Class WpfdControllerCategory
 */
class WpfdControllerCategory extends Controller
{
    /**
     * Add new a category
     *
     * @return void
     */
    public function addCategory()
    {
        Utilities::getInput('type');
        $model = $this->getModel();
        $id = $model->addCategory(esc_html__('New category', 'wpfd'));
        if ($id) {
            $user_id = get_current_user_id();
            if ($user_id) {
                $user_categories = get_user_meta($user_id, 'wpfd_user_categories', true);
                if (is_array($user_categories)) {
                    if (!in_array($id, $user_categories)) {
                        $user_categories[] = $id;
                    }
                } else {
                    $user_categories = array();
                    $user_categories[] = $id;
                }
                update_user_meta($user_id, 'wpfd_user_categories', $user_categories);
            }
            $this->exitStatus(true, array('id_category' => $id, 'name' => esc_html__('New category', 'wpfd')));
        }
        $this->exitStatus('error while adding category'); //todo: translate
    }

    /**
     * Rename category title
     *
     * @return void
     */
    public function setTitle()
    {
        $category = Utilities::getInt('id_category', 'POST');
        $title = Utilities::getInput('title', 'POST', 'string');
        $model = $this->getModel();
        if ($model->saveTitle($category, $title)) {
            do_action('wpfdAddonSetCategoryGoogleDriveTitle', $category, $title);
            do_action('wpfdAddonSetCategoryDropboxTitle', $category, $title);
            do_action('wpfdAddonSetCategoryOneDriveTitle', $category, $title);
            $this->exitStatus(true);
        }
        $this->exitStatus(esc_html__('Error while saving title', 'wpfd')); //todo: translate
    }

    /**
     * Save file params
     *
     * @return void
     */
    public function saveparams()
    {
        $modelRoles = $this->getModel('roles');
        $params = Utilities::getInput('params', 'POST', 'none');
        $id = Utilities::getInput('id', 'GET', 'int');
        $roles = isset($params['roles']) ? $params['roles'] : array();
        if (!$modelRoles->save($id, $params['visibility'], $roles)) {
            $this->exitStatus(false, 'error while saving');
        }
        $model = $this->getModel();
        if (!$model->saveParams($id, $params)) {
            $this->exitStatus(false, esc_html__('Error while saving category\'s parameters', 'wpfd'));
        }
        $this->exitStatus(true);
    }

    /**
     * Change order categories
     *
     * @return void
     */
    public function changeOrder()
    {
        if (!wp_verify_nonce(Utilities::getInput('security', 'GET', 'none'), 'wpfd-security')) {
            $this->exitStatus(esc_html__('Wrong security Code!', 'wpfd'));
        }
        $pk = Utilities::getInt('pk');
        $ref = Utilities::getInt('ref');
        $position = Utilities::getInput('position', 'GET', 'string');
        $dragType = Utilities::getInput('dragType', 'GET', 'none');
        $model = $this->getModel();
        if ($model->changeOrder($pk, $ref, $position)) {
            if ($dragType === 'googledrive') {
                apply_filters('wpfdAddonGoogleDriveChangeOrder', $pk);
            } elseif ($dragType === 'dropbox') {
                apply_filters('wpfdAddonDropboxChangeOrder', $pk, $ref);
            } elseif ($dragType === 'onedrive') {
                apply_filters('wpfdAddonOneDriveChangeOrder', $pk);
            }
            $this->exitStatus(true);
        }
        $this->exitStatus('problem');
    }

    /**
     * Order categories
     *
     * @return void
     */
    public function order()
    {
        if (Utilities::getInput('position') === 'after') {
            $position = 'after';
        } else {
            $position = 'first-child';
        }
        $pk = Utilities::getInt('pk');
        $ref = Utilities::getInt('ref');
        if ($ref === 0) {
            $ref = 1;
        }
        $model = $this->getModel();
        if ($model->move($pk, $ref, $position)) {
            $this->exitStatus(true, $pk . ' ' . $position . ' ' . $ref);
        }
        $this->exitStatus('problem');
    }

    /**
     * Delete category
     *
     * @return void
     */
    public function delete()
    {
        if (!wp_verify_nonce(Utilities::getInput('security', 'POST', 'none'), 'wpfd-security')) {
            $this->exitStatus(false, array('message' => 'Verify false!'));
        }
        $category = Utilities::getInt('id_category');
        $model = $this->getModel();

        $children = $model->getChildren($category);

        if ($model->delete($category)) {
            $children[] = $category;
            foreach ($children as $child) {
                $dir = WpfdBase::getFilesPath($child);
                WpfdTool::rrmdir($dir);
                if ($child === $category) {
                    continue;
                }
                $model->delete($child);
            }
            $this->exitStatus(true);
        }
        $this->exitStatus(esc_html__('Error while deleting category!', 'wpfd'));
    }

    /**
     * List categories for jaofiletree
     *
     * @return void
     */
    public function listdir()
    {
        $return = array();
        $dirs = array();
        $fi = array();

        if (!is_admin()) {
            echo json_encode(array());
        }

        $modelConfig = $this->getModel('config');
        $config = $modelConfig->getConfig();
        $allowed_ext = explode(',', $config['allowedext']);
        foreach ($allowed_ext as $key => $value) {
            $allowed_ext[$key] = strtolower(trim($allowed_ext[$key]));
            if ($allowed_ext[$key] === '') {
                unset($allowed_ext[$key]);
            }
        }

        $path = get_home_path() . DIRECTORY_SEPARATOR;

        $dir = Utilities::getInput('dir', 'GET', 'none');

        if (file_exists($path . $dir)) {
            $files = scandir($path . $dir);

            natcasesort($files);
            if (is_countable($files) && count($files) > 2) {
                // All dirs
                foreach ($files as $file) {
                    if (file_exists($path . $dir . DIRECTORY_SEPARATOR . $file) &&
                        $file !== '.' && $file !== '..' && is_dir($path . $dir . DIRECTORY_SEPARATOR . $file)
                    ) {
                        $dirs[] = array('type' => 'dir', 'dir' => $dir, 'file' => $file);
                    } elseif (file_exists($path . $dir . DIRECTORY_SEPARATOR . $file) && $file !== '.' &&
                        $file !== '..' && !is_dir($path . $dir . DIRECTORY_SEPARATOR . $file) &&
                        in_array(wpfd_getext($file), $allowed_ext)
                    ) {
                        $fi[] = array(
                            'type' => 'file',
                            'dir' => $dir,
                            'file' => $file,
                            'ext' => strtolower(wpfd_getext($file))
                        );
                    }
                }
                $return = array_merge($dirs, $fi);
            }
        }
        echo json_encode($return);
        wp_die();
    }
}
