<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

use Joomunited\WPFramework\v1_0_4\Controller;
use Joomunited\WPFramework\v1_0_4\Form;
use Joomunited\WPFramework\v1_0_4\Model;
use Joomunited\WPFramework\v1_0_4\Utilities;

defined('ABSPATH') || die();

/**
 * Class WpfdControllerFile
 */
class WpfdControllerFile extends Controller
{
    /**
     * Download file
     *
     * @return void
     */
    public function download()
    {
        $model = $this->getModel();
        $id = Utilities::getInt('id');
        $version = Utilities::getInput('version', 'GET', 'string');
        $catid = Utilities::getInt('catid');
        if (apply_filters('wpfdAddonCategoryFrom', $catid) === 'dropbox') {
            $id_file = Utilities::getInput('id', 'GET', 'string');
            $vid = Utilities::getInput('vid', 'GET', 'string');
            if ($version) {
                apply_filters('wpfdAddonDownloadVersion', $id_file, $vid);
            }
            exit();
        } else {
            $file = $model->getFile($id);
            $remote_url = false;
            $url = '';
            if (!$version) {
                $file = $model->getFile($id);
                $file_meta = get_post_meta($id, '_wpfd_file_metadata', true);
                $remote_url = isset($file_meta['remote_url']) ? $file_meta['remote_url'] : false;
                $url = $file_meta['file'];
            } else {
                $vid = Utilities::getInt('vid');
                $version = $model->getVersion($vid);
                if ($version) {
                    $file = array_merge($file, $version);
                    if ($version['remote_url']) {
                        $remote_url = true;
                        $url = $version['file'];
                    }
                }
            }

            //todo : verifier les droits d'acces à la catéorgie du fichier
            if (!WpfdHelperFile::checkAccess($file)) {
                exit();
            }
            if (!empty($file) && $file['ID']) {
                $filename = WpfdHelperFile::santizeFileName($file['title']);
                if ($filename === '') {
                    $filename = 'download';
                }
                if ($remote_url) {
                    header('Location: ' . $url);
                } else {
                    $sysfile = WpfdBase::getFilesPath($file['catid']) . '/' . $file['file'];
                    WpfdHelperFile::sendDownload(
                        $sysfile,
                        basename($filename . '.' . $file['ext']),
                        $file->ext
                    );
                }
            }
            exit();
        }
    }

    /**
     * Restore file
     *
     * @return void
     */
    public function restore()
    {
        $id_file = Utilities::getInt('id');
        $vid = Utilities::getInt('vid');
        $catid = Utilities::getInt('catid');
        if (apply_filters('wpfdAddonCategoryFrom', $catid) === 'dropbox') {
            $id_file = Utilities::getInput('id', 'GET', 'string');
            $vid = Utilities::getInput('vid', 'GET', 'string');
            $version = apply_filters('wpfdAddonRestoreVersion', $id_file, $vid);
            $this->exitStatus($version);
        } else {
            $model = $this->getModel();
            $file = $model->getFile($id_file);
            $version = $model->getVersion($vid);

            if ($version) {
                $model->updateFile($id_file, array(
                    'title' => $file['title'],
                    'file' => $version['file'],
                    'ext' => $version['ext'],
                    'size' => $version['size'],
                    'version' => $version['version'],
                    'remote_url' => $version['remote_url']
                ));

                $model->deleteVersion($vid);
                $this->exitStatus(true);
            }
            $this->exitStatus(false);
        }
    }

    /**
     * Delete file version
     *
     * @return void
     */
    public function deleteVersion()
    {

        $idCategory = Utilities::getInt('catid');
        if (apply_filters('wpfdAddonCategoryFrom', $idCategory) === 'googleDrive') {
            $id_file = Utilities::getInput('id_file', 'GET', 'none');
            $vid = Utilities::getInput('vid', 'GET', 'none');
            if (apply_filters('wpfdAddonDeleteVersion', $idCategory, $id_file, $vid)) {
                $this->exitStatus(true, array());
            } else {
                $this->exitStatus('error validating');
            }
        } else {
            $vid = Utilities::getInt('vid');
            $model = $this->getModel();
            $id_file = Utilities::getInput('id_file', 'GET', 'none');
            $file = $model->getFile($id_file);
            $version = $model->getVersion($vid);
            $file_dir = WpfdBase::getFilesPath($file['catid']) . '/' . $version['file'];
            $result = (bool)$model->deleteVersion($vid);
            if ($result) {
                if (file_exists($file_dir)) {
                    unlink($file_dir);
                }
            }
            $this->exitStatus($result);
        }
    }

    /**
     * Save file
     *
     * @return void
     */
    public function save()
    {
        $model = $this->getModel();
        $modelCat = $this->getModel('category');
        $modelNotify = $this->getModel('notification');
        $configNotify = $modelNotify->getNotificationsConfig();
        $modelConfig = $this->getModel('config');
        $config = $modelConfig->getConfig();
        $dateFormat = $config['date_format'];

        //file multi category
        $file_multi_category_input = Utilities::getInput('file_multi_category', 'POST', 'none');
        if (strstr($file_multi_category_input, ',')) {
            $file_multi_category = explode(',', $file_multi_category_input);
        } else {
            $file_multi_category = array($file_multi_category_input);
        }

        $file_multi_category_old_input = Utilities::getInput('file_multi_category_old', 'POST', 'none');
        if (strstr($file_multi_category_old_input, ',')) {
            $file_multi_category_old = explode(',', $file_multi_category_old_input);
        } else {
            $file_multi_category_old = array($file_multi_category_old_input);
        }

        $id_file = Utilities::getInt('id');
        $form = new Form();

        if (!$form->load('file')) {
            $this->exitStatus('error');
        }
        $data = $form->sanitize();
        // Publish date only for local file
        //if ($data['publish'] !== '' && $data['publish'] !== '0000-00-00 00:00:00') {
            //$data['publish'] = WpfdBase::validateDate($data['publish'], $dateFormat);
        //}
        $data['file_multi_category'] = $file_multi_category;
        if ($file_multi_category && is_array($file_multi_category)) {
            $data['file_multi_category_old'] = implode(',', $file_multi_category);
        }

        $idCategory = Utilities::getInt('idCategory');
        $category = $modelCat->getCategory($idCategory);
        if (apply_filters('wpfdAddonCategoryFrom', $idCategory) === 'googleDrive') {
            $fileId = Utilities::getInput('id', 'GET', 'none');
            $data['id'] = $fileId;
            if (apply_filters('wpfdAddonSaveFileInfo', $data)) {
                $this->saveCatRefToFiles(
                    $modelCat,
                    $file_multi_category_old,
                    $file_multi_category,
                    $fileId,
                    $idCategory
                );
                $this->sendEmail(
                    'edited',
                    null,
                    $category->params['category_own'],
                    $configNotify,
                    $category->name,
                    $data['title']
                );
                $this->exitStatus(true);
            } else {
                $this->exitStatus('error saving');
            }
        } elseif (apply_filters('wpfdAddonCategoryFrom', $idCategory) === 'dropbox') {
            $fileId = Utilities::getInput('id', 'GET', 'none');
            $data['id'] = $fileId;
            $new_id = apply_filters('wpfdAddonSaveDropboxFileInfo', $data, $idCategory);
            $this->saveCatRefToFiles($modelCat, $file_multi_category_old, $file_multi_category, $fileId, $idCategory);
            if (!empty($new_id)) {
                $this->sendEmail(
                    'edited',
                    null,
                    $category->params['category_own'],
                    $configNotify,
                    $category->name,
                    $data['title']
                );
                $this->exitStatus(true, array('new_id' => $new_id));
            } else {
                $this->exitStatus('error saving');
            }
        } elseif (apply_filters('wpfdAddonCategoryFrom', $idCategory) === 'onedrive') {
            $fileId = Utilities::getInput('id', 'GET', 'none');
            $data['id'] = $fileId;
            $new_id = apply_filters('wpfdAddonSaveOneDriveFileInfo', $data, $idCategory);
            $this->saveCatRefToFiles($modelCat, $file_multi_category_old, $file_multi_category, $fileId, $idCategory);
            if (!empty($new_id)) {
                $this->sendEmail(
                    'edited',
                    null,
                    $category->params['category_own'],
                    $configNotify,
                    $category->name,
                    $data['title']
                );
                $this->exitStatus(true, array('new_id' => $new_id));
            } else {
                $this->exitStatus('error saving');
            }
        } else {
            $data['id'] = $id_file;

            $data['description'] = Utilities::getInput('description', 'POST', 'none');
            if (!$model->save($data)) {
                $this->exitStatus('error saving');
            }
            $this->saveCatRefToFiles($modelCat, $file_multi_category_old, $file_multi_category, $id_file, $idCategory);
            $file = $model->getFile($data['id']);
            $this->sendEmail(
                'edited',
                $file['post_author'],
                $category->params['category_own'],
                $configNotify,
                $category->name,
                $file['post_title']
            );
            $this->exitStatus(true);
        }
    }

    /**
     * Save multiple category to file meta
     *
     * @param mixed   $modelCat                Category model
     * @param array   $file_multi_category_old Old category list
     * @param array   $file_multi_category     Category list
     * @param string  $id_file                 File id
     * @param integer $idCategory              Category id
     *
     * @return void
     */
    public function saveCatRefToFiles($modelCat, $file_multi_category_old, $file_multi_category, $id_file, $idCategory)
    {
        $lst_catRef_del = array();
        if ((!empty($file_multi_category_old) && $file_multi_category) && $file_multi_category_old) {
            $lst_catRef_del = array_diff($file_multi_category_old, $file_multi_category);
        }
        if (!empty($file_multi_category) && $file_multi_category) {
            foreach ($file_multi_category as $value) {
                if (trim($value) !== '') {
                    $modelCat->saveRefToFiles($value, $id_file, $idCategory);
                }
            }
            if (!empty($lst_catRef_del) && $lst_catRef_del) {
                foreach ($lst_catRef_del as $value) {
                    if (trim($value) !== '') {
                        $modelCat->deleteRefToFiles($value, $id_file, $idCategory);
                    }
                }
            }
        } elseif (!empty($file_multi_category_old)) {
            foreach ($file_multi_category_old as $value) {
                if (trim($value) !== '') {
                    $modelCat->deleteRefToFiles($value, $id_file, $idCategory);
                }
            }
        }
    }

    /**
     * Delete file
     *
     * @return void
     */
    public function delete()
    {
        $idCategory = Utilities::getInt('id_category');
        $catIdFileRef = Utilities::getInt('catid_file_ref');
        $modelCat = $this->getModel('category');
        $category = $modelCat->getCategory($idCategory);
        $modelNotify = $this->getModel('notification');
        $configNotify = $modelNotify->getNotificationsConfig();

        $whereDelete = apply_filters('wpfdAddonCategoryFrom', $idCategory);

        if ($whereDelete === 'googleDrive') {
            $id_file = Utilities::getInput('id_file', 'GET', 'string');
            $file = apply_filters('wpfdAddonGetFileInfo', $id_file);
            $this->sendEmail(
                'delete',
                null,
                $category->params['category_own'],
                $configNotify,
                $category->name,
                $file['title']
            );
            do_action('wpfdAddonDeleteGoogleCloudFiles', $idCategory, $id_file);
        } elseif ($whereDelete === 'dropbox') {
            $id_file = Utilities::getInput('id_file', 'GET', 'string');
            $file = apply_filters('wpfdAddonDropboxGetFileInfo', $id_file, $idCategory);
            $this->sendEmail(
                'delete',
                null,
                $category->params['category_own'],
                $configNotify,
                $category->name,
                $file['title']
            );
            do_action('wpfdAddonDeleteDropboxFiles', $idCategory, $id_file);
        } elseif ($whereDelete === 'onedrive') {
            $id_file = Utilities::getInput('id_file', 'GET', 'string');
            $file = apply_filters('wpfdAddonOneDriveGetFileInfo', $id_file, $idCategory);
            $this->sendEmail(
                'delete',
                null,
                $category->params['category_own'],
                $configNotify,
                $category->name,
                $file['title']
            );
            do_action('wpfdAddonDeleteOneDriveFiles', $idCategory, $id_file);
        } else {
            $id_file = Utilities::getInt('id_file');
            $model = $this->getModel();
            $versions = $model->getVersions($id_file, $idCategory);
            $file = $model->getFile($id_file);

            if (!empty($versions)) {
                foreach ($versions as $key => $value) {
                    $version = $model->getVersion($value['meta_id']);
                    $file_dir = WpfdBase::getFilesPath($file['catid']) . '/' . $version['file'];
                    $result = (bool)$model->deleteVersion($value['meta_id']);
                    if ($result) {
                        if (file_exists($file_dir)) {
                            unlink($file_dir);
                        }
                    }
                }
            }
            if (!empty($file)) {
                if ($catIdFileRef === $idCategory) {
                    $file_multi_category = null;
                    if (isset($file['file_multi_category'])) {
                        $file_multi_category = $file['file_multi_category'];
                    }
                    if ($file_multi_category) {
                        foreach ($file_multi_category as $value) {
                            $modelCat->deleteRefToFiles($value, $id_file, $idCategory);
                        }
                    }
                    if ($model->delete($id_file)) {
                        $file_dir = WpfdBase::getFilesPath($file['catid']);
                        if (file_exists($file_dir . $file['file'])) {
                            unlink($file_dir . $file['file']);
                            $this->sendEmail(
                                'delete',
                                $file['post_author'],
                                $category->params['category_own'],
                                $configNotify,
                                $category->name,
                                $file['post_title']
                            );
                            // Full Text Search Index When Delete File
                            $ftsModel = Model::getInstance('fts');
                            $ftsModel->removeIndexRecordForPost($id_file);

                            $this->exitStatus(true);
                        }
                    }
                } else {
                    $modelCat->deleteRefToFiles($idCategory, $id_file, $catIdFileRef);
                    $metadata = get_post_meta($file['ID'], '_wpfd_file_metadata', true);
                    if (isset($metadata['file_multi_category'])) {
                        $file_multi_category = $metadata['file_multi_category'];
                        foreach ($file_multi_category as $key => $val) {
                            if ($idCategory === (int)$val) {
                                unset($file_multi_category[$key]);
                            }
                        }
                        $metadata['file_multi_category'] = $file_multi_category;
                        $metadata['file_multi_category_old'] = implode(',', $file_multi_category);
                        update_post_meta($file['ID'], '_wpfd_file_metadata', $metadata);
                    }
                }
                $this->exitStatus('error while deleting');
            }
        }
    }

    /**
     * Send email
     *
     * @param string       $action       Action to send email
     * @param integer|null $user_id      Current user id
     * @param string       $cat_userid   Category owner id
     * @param array        $configNotify Email configurations
     * @param string       $cat_name     Category had action
     * @param string       $file_title   File name in action
     *
     * @return void
     */
    public function sendEmail($action, $user_id, $cat_userid, $configNotify, $cat_name, $file_title)
    {
        $send_mail_active = array();
        $cat_user_id[] = $cat_userid;
        $list_superAdmin = WpfdHelperFiles::getListIDSuperAdmin();
        if ((int)$configNotify['notify_file_owner'] === 1 && $user_id !== null) {
            $user = get_userdata($user_id)->data;
            array_push($send_mail_active, $user->user_email);
            WpfdHelperFiles::sendMail($action, $user, $cat_name, get_site_url(), $file_title);
        }
        if ((int)$configNotify['notify_category_owner'] === 1) {
            foreach ($cat_user_id as $item) {
                $user = get_userdata($item)->data;
                if (!in_array($user->user_email, $send_mail_active)) {
                    array_push($send_mail_active, $user->user_email);
                    WpfdHelperFiles::sendMail($action, $user, $cat_name, get_site_url(), $file_title);
                }
            }
        }
        if ($configNotify['notify_add_event_email'] !== '') {
            $emails = explode(',', $configNotify['notify_add_event_email']);
            foreach ($emails as $item) {
                $obj_user = new stdClass;
                $obj_user->display_name = '';
                $obj_user->user_email = $item;
                if (!in_array($item, $send_mail_active)) {
                    array_push($send_mail_active, $item);
                    WpfdHelperFiles::sendMail($action, $obj_user, $cat_name, get_site_url(), $file_title);
                }
            }
        }
        if ((int)$configNotify['notify_super_admin'] === 1) {
            foreach ($list_superAdmin as $items) {
                $user = get_userdata($items)->data;
                if (!in_array($user->user_email, $send_mail_active)) {
                    array_push($send_mail_active, $user->user_email);
                    WpfdHelperFiles::sendMail($action, $user, $cat_name, get_site_url(), $file_title);
                }
            }
        }
    }
}
