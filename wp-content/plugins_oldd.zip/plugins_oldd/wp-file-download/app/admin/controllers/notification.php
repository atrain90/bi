<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

use Joomunited\WPFramework\v1_0_4\Controller;
use Joomunited\WPFramework\v1_0_4\Form;
use Joomunited\WPFramework\v1_0_4\Application;
use Joomunited\WPFramework\v1_0_4\Utilities;

defined('ABSPATH') || die();

/**
 * Class WpfdControllerNotification
 */
class WpfdControllerNotification extends Controller
{
    /**
     * Save notifications params
     *
     * @return void
     */
    public function savenotificationsparams()
    {
        $model = $this->getModel();

        $form     = new Form();
        $formfile = Application::getInstance('Wpfd')->getPath() . DIRECTORY_SEPARATOR . 'admin' . DIRECTORY_SEPARATOR;
        $formfile .= 'forms' . DIRECTORY_SEPARATOR . 'notifications.xml';
        if (!$form->load($formfile)) {
            $this->redirect('admin.php?page=wpfd-notification&error=1');
        }
        if (!$form->validate()) {
            $this->redirect('admin.php?page=wpfd-notification&error=2');
        }
        $datas                                 = $form->sanitize();
        $datas['notify_add_event_editor']      = Utilities::getInput('notify_add_event_editor', 'POST', 'none');
        $datas['notify_edit_event_editor']     = Utilities::getInput('notify_edit_event_editor', 'POST', 'none');
        $datas['notify_delete_event_editor']   = Utilities::getInput('notify_delete_event_editor', 'POST', 'none');
        $datas['notify_download_event_editor'] = Utilities::getInput('notify_download_event_editor', 'POST', 'none');
        if (!$model->saveNotifications($datas)) {
            $this->redirect('admin.php?page=wpfd-notification&error=3');
        }
        $this->redirect('admin.php?page=wpfd-notification&msg=' . esc_html__('success', 'wpfd'));
    }

    /**
     * Save mail option params
     *
     * @return void
     */
    public function savemailoption()
    {
        $model = $this->getModel();

        $form     = new Form();
        $formfile = Application::getInstance('Wpfd')->getPath() . DIRECTORY_SEPARATOR . 'admin' . DIRECTORY_SEPARATOR;
        $formfile .= 'forms' . DIRECTORY_SEPARATOR . 'mail_option.xml';
        if (!$form->load($formfile)) {
            $this->redirect('admin.php?page=wpfd-notification&error=1');
        }
        if (!$form->validate()) {
            $this->redirect('admin.php?page=wpfd-notification&error=2');
        }
        $datas = $form->sanitize();
        if (!$model->saveMailOption($datas)) {
            $this->redirect('admin.php?page=wpfd-notification&error=3');
        }
        $this->redirect('admin.php?page=wpfd-notification&msg=' . esc_html__('success', 'wpfd'));
    }
}
