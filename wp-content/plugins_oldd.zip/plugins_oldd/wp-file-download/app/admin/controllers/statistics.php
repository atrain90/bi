<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

use Joomunited\WPFramework\v1_0_4\Controller;

defined('ABSPATH') || die();

/**
 * Class WpfdControllerStatistics
 */
class WpfdControllerStatistics extends Controller
{
}
