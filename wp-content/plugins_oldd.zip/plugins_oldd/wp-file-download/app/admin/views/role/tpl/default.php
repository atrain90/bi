<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

// No direct access.
use Joomunited\WPFramework\v1_0_4\Application;

defined('ABSPATH') || die();

global $wp_roles;

if (!isset($wp_roles)) {
    // phpcs:ignore WordPress.WP.GlobalVariablesOverride.OverrideProhibited -- create if wp_roles is null
    $wp_roles = new WP_Roles();
}

$roles          = $wp_roles->role_objects;
$roles_names    = $wp_roles->role_names;
$post_type      = get_post_type_object('wpfd_file');
$post_type_caps = $post_type->cap;

?>
<div id="mybootstrap" class="wrap wpfd-role">
    <div id="icon-options-general" class="icon32"></div>
    <h3><?php esc_html_e('User Roles', 'wpfd'); ?></h3>

    <form id="wpfd-role-form" method="post" action="admin.php?page=wpfd-role&amp;task=role.save">
        <?php wp_nonce_field('wpfd_role_settings', 'wpfd_role_nonce'); ?>
        <ul id="wpfd-tabs" class="nav-tab-wrapper">
            <?php
            $tab_count = 0;
            foreach ($roles_names as $key => $name) {
                $new_key  = str_replace(' ', '_', $key);
                $li_class = '';
                if ($tab_count === 0) {
                    $li_class = 'active';
                }
                echo '<a class="nav-tab ' . esc_attr($li_class) . '" 
                href="#role-' . esc_attr($new_key) . '" data-tab-id="' . esc_attr($new_key) . '"> ' . esc_html($name) . ' </a> ';
                $tab_count++;
            }
            ?>
        </ul>
        <div id="wpfd-tabs-content" class="tab-content">
            <?php
            $role_count = 0;
            foreach ($roles as $role_name => $role) {
                $new_role_name = str_replace(' ', '_', $role_name);
                ?>
                <div class="tab-pane <?php echo ($role_count === 0) ? 'active' : ''; ?>"
                     id="<?php echo esc_attr('wpfd-role-' . $new_role_name); ?>">
                    <?php
                    $caps            = (array) $post_type_caps;
                    $wp_default_caps = array(
                        'read',
                        'read_post',
                        'read_private_posts',
                        'create_posts',
                        'edit_posts',
                        'edit_post',
                        'edit_others_posts',
                        'delete_post',
                        'publish_posts'
                    );
                    foreach ($wp_default_caps as $default_cap) {
                        unset($caps[$default_cap]);
                    }
                    foreach ($caps as $post_key => $post_cap) {
                        ?>
                        <label for="<?php echo esc_attr('wpfd-' . $new_role_name . '-' . $post_key . '-edit'); ?>">
                            <input type="checkbox"
                                   id="<?php echo esc_attr('wpfd-' . $new_role_name . '-' . $post_cap . '-edit'); ?>"
                                   name="<?php echo esc_attr($new_role_name . '[' . $post_key . ']'); ?>"
                                <?php checked(isset($role->capabilities[$post_key]), 1); ?> />
                            <?php
                            // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralText -- Dynamic translate
                            esc_html_e($post_cap, 'wpfd');
                            ?>
                        </label>
                    <?php }
                    $role_count++;
                    ?>
                </div>
            <?php } ?>

        </div>

        <p class="submit">
            <input type="submit" name="submit" class="button button-primary"
                   value="<?php esc_html_e('Save', 'wpfd'); ?>"/>
        </p>
    </form>

</div>
<script type="text/javascript">
    jQuery(document).ready(function ($) {
        $("#wpfd-tabs .nav-tab").click(function (e) {
            e.preventDefault();
            $("#wpfd-tabs .nav-tab").removeClass('active');
            $(e.target).addClass('active');
            id_tab = $(this).data('tab-id');
            $("#wpfd-tabs-content .tab-pane").removeClass('active');
            $("#wpfd-role-" + id_tab).addClass('active');
        })
    });
    wpfdajaxurl = "<?php echo wpfd_sanitize_ajax_url(Application::getInstance('Wpfd')->getAjaxUrl()); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- keep this, if not it error ?>";
</script>
