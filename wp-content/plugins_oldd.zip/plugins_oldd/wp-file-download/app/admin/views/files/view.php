<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

use Joomunited\WPFramework\v1_0_4\Application;
use Joomunited\WPFramework\v1_0_4\View;
use Joomunited\WPFramework\v1_0_4\Utilities;

defined('ABSPATH') || die();

/**
 * Class WpfdViewFiles
 */
class WpfdViewFiles extends View
{
    /**
     * Render view all files
     *
     * @param null $tpl Template name
     *
     * @return string
     */
    public function render($tpl = null)
    {
        $id_category = Utilities::getInt('id_category');
        if (empty($id_category)) {
            return '';
        }
        Application::getInstance('Wpfd');
        $model             = $this->getModel();
        $category_model    = $this->getModel('category');
        $orderCol          = Utilities::getInput('orderCol', 'GET', 'none');
        $orderDir          = Utilities::getInput('orderDir', 'GET', 'none');
        $this->category    = $category_model->getCategory($id_category);
        $this->ordering    = $orderCol !== null ? $orderCol : $this->category->ordering;
        $this->orderingdir = $orderDir !== null ? $orderDir : $this->category->orderingdir;
        $modelConfig       = $this->getModel('config');
        $this->params      = $modelConfig->getConfig();
        $description       = json_decode($this->category->description, true);
        $lstAllFile        = null;
        if (!empty($description) && isset($description['refToFile'])) {
            if (isset($description['refToFile'])) {
                $listCatRef = $description['refToFile'];
                $lstAllFile = $this->getAllFileRef($model, $listCatRef, $this->ordering, $this->orderingdir);
            }
        }
        if (apply_filters('wpfdAddonCategoryFrom', $id_category) === 'googleDrive') {
            $this->files = apply_filters('wpfdAddonDisplayGoogleDriveCategories', $id_category);
        } elseif (apply_filters('wpfdAddonCategoryFrom', $id_category) === 'dropbox') {
            $this->files = apply_filters('wpfdAddonDisplayDropboxCategories', $id_category);
        } elseif (apply_filters('wpfdAddonCategoryFrom', $id_category) === 'onedrive') {
            $this->files = apply_filters('wpfdAddonDisplayOneDriveCategories', $id_category);
        } else {
            $this->files = $model->getFiles($id_category, $this->ordering, $this->orderingdir);
        }
        if ($lstAllFile && !empty($lstAllFile)) {
            $this->files = array_merge($lstAllFile, $this->files);
        }
        $reverse = strtoupper($orderDir) === 'DESC' ? true : false;
        if ($orderCol === 'size') {
            $this->files = wpfd_sort_by_property($this->files, 'size', 'ID', $reverse);
        } elseif ($orderCol === 'version') {
            $this->files = wpfd_sort_by_property($this->files, 'versionNumber', 'ID', $reverse);
        } elseif ($orderCol === 'hits') {
            $this->files = wpfd_sort_by_property($this->files, 'hits', 'ID', $reverse);
        } elseif ($orderCol === 'ext') {
            $this->files = wpfd_sort_by_property($this->files, 'ext', 'ID', $reverse);
        } elseif ($orderCol === 'description') {
            $this->files = wpfd_sort_by_property($this->files, 'description', 'ID', $reverse);
        } elseif ($orderCol === 'title') {
            $this->files = wpfd_sort_by_property($this->files, 'post_name', 'ID', $reverse);
        }
        parent::render($tpl);
    }

    /**
     * Get all file referent
     *
     * @param object $model       Files model
     * @param array  $listCatRef  List category
     * @param string $ordering    Ordering
     * @param string $orderingdir Ordering direction
     *
     * @return array
     */
    public function getAllFileRef($model, $listCatRef, $ordering, $orderingdir)
    {
        $lstAllFile = array();
        foreach ($listCatRef as $key => $value) {
            if (is_array($value) && !empty($value)) {
                $lstFile    = $model->getFilesRef($key, $value, $ordering, $orderingdir);
                $lstAllFile = array_merge($lstFile, $lstAllFile);
            }
        }

        return $lstAllFile;
    }
}
