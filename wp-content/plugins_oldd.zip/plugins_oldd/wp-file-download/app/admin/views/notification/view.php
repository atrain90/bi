<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

use Joomunited\WPFramework\v1_0_4\View;
use Joomunited\WPFramework\v1_0_4\Form;
use Joomunited\WPFramework\v1_0_4\Application;

defined('ABSPATH') || die();

/**
 * Class WpfdViewNotification
 */
class WpfdViewNotification extends View
{
    /**
     * Render view notification
     *
     * @param null $tpl Template name
     *
     * @return void
     */
    public function render($tpl = null)
    {
        Application::getInstance('Wpfd');
        $modelNotify                = $this->getModel('notification');
        $this->notifications_config = $modelNotify->getNotificationsConfig();
        $this->mail_option_config   = $modelNotify->getMailOptionConfig();
        $notifications_form         = new Form();
        if ($notifications_form->load('notifications', $this->notifications_config)) {
            $this->notifications_form = $notifications_form->render();
        }

        Application::getInstance('Wpfd');
        $mailoption_form = new Form();
        if ($mailoption_form->load('mail_option', $this->mail_option_config)) {
            $this->mailoption_form = $mailoption_form->render();
        }
        parent::render($tpl);
    }
}
