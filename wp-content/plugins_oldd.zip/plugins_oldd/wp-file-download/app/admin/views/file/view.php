<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

use Joomunited\WPFramework\v1_0_4\Application;
use Joomunited\WPFramework\v1_0_4\View;
use Joomunited\WPFramework\v1_0_4\Utilities;
use Joomunited\WPFramework\v1_0_4\Form;

defined('ABSPATH') || die();

/**
 * Class WpfdViewFile
 */
class WpfdViewFile extends View
{
    /**
     * Render view file
     *
     * @param null $tpl Template name
     *
     * @return void
     */
    public function render($tpl = null)
    {
        Application::getInstance('Wpfd');
        $model      = $this->getModel('file');
        $idCategory = null;
        $fileId     = null;
        if (!isset($_POST['security']) || !wp_verify_nonce($_POST['security'], 'wpfd-security')) {
            wp_die(esc_html__('You don\'t have permission to perform this action!', 'wpfd'));
        }
        if (isset($_POST['fileInfo'][0])) {
            if (isset($_POST['fileInfo'][0]['fileId'])) {
                $fileId = esc_html($_POST['fileInfo'][0]['fileId']);
            }
            if (isset($_POST['fileInfo'][0]['catid'])) {
                $idCategory = (int) $_POST['fileInfo'][0]['catid'];
            }
        }
        
        if (apply_filters('wpfdAddonCategoryFrom', $idCategory) === 'googleDrive') {
            $datas = apply_filters('wpfdAddonGetFileInfo', $fileId);
        } elseif (apply_filters('wpfdAddonCategoryFrom', $idCategory) === 'dropbox') {
            $datas = apply_filters('wpfdAddonDropboxGetFileInfo', $fileId, $idCategory);
        } elseif (apply_filters('wpfdAddonCategoryFrom', $idCategory) === 'onedrive') {
            $datas = apply_filters('wpfdAddonOneDriveGetFileInfo', $fileId, $idCategory);
        } else {
            $datas = $model->getfile($fileId);
        }
        $layout = Utilities::getInput('layout', 'GET', 'string');
        if ($layout === 'versions') {
            $this->file_id = $datas['ID'];
            if (apply_filters('wpfdAddonCategoryFrom', $idCategory) === 'dropbox') {
                $this->versions = apply_filters('wpfdAddonDropboxVersionInfo', $datas['ID'], $idCategory);
            } else {
                $this->versions = $model->getVersions($datas['ID'], $idCategory);
            }
            parent::render($layout);
            wp_die();
        }
        // Fix wrong instance
        //Application::getInstance('Wpfd');
        $form = new Form();
        if ($form->load('file', $datas)) {
            $this->form = $form->render('link');
        }

        $tags = get_terms('wpfd-tag', array(
            'orderby'    => 'count',
            'hide_empty' => 0,
        ));
        if ($tags) {
            $allTagsFiles = array();
            foreach ($tags as $tag) {
                $allTagsFiles[] = '' . esc_html($tag->slug);
            }
            $this->allTagsFiles = '["' . implode('","', $allTagsFiles) . '"]';
        } else {
            $this->allTagsFiles = '[]';
        }
        parent::render($tpl);
        wp_die();
    }
}
