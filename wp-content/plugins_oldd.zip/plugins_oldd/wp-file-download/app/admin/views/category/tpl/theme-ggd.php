<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

// No direct access.
defined('ABSPATH') || die();

?>
<fieldset>
    <legend><?php esc_html_e('Category layout', 'wpfd'); ?></legend>
    <div class="control-group">
        <label class="control-label" for="marginleft"><?php esc_html_e('Margin left', 'wpfd'); ?></label>
        <div class="controls">
            <input title="" name="params[ggd_marginleft]" value="<?php echo esc_attr($this->params['ggd_marginleft']); ?>"
                   class="inputbox input-block-level" type="text">
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="marginright"><?php esc_html_e('Margin right', 'wpfd'); ?></label>
        <div class="controls">
            <input title="" name="params[ggd_marginright]" value="<?php echo esc_attr($this->params['ggd_marginright']); ?>"
                   class="inputbox input-block-level" type="text">
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="margintop"><?php esc_html_e('Margin top', 'wpfd'); ?></label>
        <div class="controls">
            <input title="" name="params[ggd_margintop]" value="<?php echo esc_attr($this->params['ggd_margintop']); ?>"
                   class="inputbox input-block-level" type="text">
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="marginbottom"><?php esc_html_e('Margin bottom', 'wpfd'); ?></label>
        <div class="controls">
            <input title="" name="params[ggd_marginbottom]"
                   value="<?php echo esc_attr($this->params['ggd_marginbottom']); ?>"
                   class="inputbox input-block-level" type="text">
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="ggd_showcategorytitle"><?php esc_html_e('Show category title', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[ggd_showcategorytitle]" class="inline">
                <option value="1" <?php echo ((int) $this->params['ggd_showcategorytitle'] === 1) ? 'selected="selected"' : ''; ?>>
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['ggd_showcategorytitle'] === 0) ? 'selected="selected"' : ''; ?>>
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="showsubcategories"><?php esc_html_e('Show subcategories', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[ggd_showsubcategories]" class="inline">
                <option value="1"
                    <?php echo ((int) $this->params['ggd_showsubcategories'] === 1) ? 'selected="selected"' : ''; ?>>
                    <?php esc_html_e('Yes', 'wpfd'); ?></option>
                <option value="0"
                    <?php echo ((int) $this->params['ggd_showsubcategories'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="ggd_showbreadcrumb"><?php esc_html_e('Show Breadcrumb', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[ggd_showbreadcrumb]" class="inline">
                <option value="1" <?php echo ((int) $this->params['ggd_showbreadcrumb'] === 1) ? 'selected="selected"' : ''; ?>>
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['ggd_showbreadcrumb'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="ggd_showfoldertree"><?php esc_html_e('Show folder tree', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[ggd_showfoldertree]" class="inline">
                <option value="1" <?php echo ((int) $this->params['ggd_showfoldertree'] === 1) ? 'selected="selected"' : ''; ?>>
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['ggd_showfoldertree'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
</fieldset>
<fieldset>
    <legend><?php esc_html_e('File block layout', 'wpfd'); ?></legend>
    <div class="control-group">
        <label class="control-label" for="showtitle"><?php esc_html_e('Show title', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[ggd_showtitle]" class="inline">
                <option value="1" <?php echo ((int) $this->params['ggd_showtitle'] === 1) ? 'selected="selected"' : ''; ?>>
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['ggd_showtitle'] === 0) ? 'selected="selected"' : ''; ?>>
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="croptitle"><?php esc_html_e('Crop titles', 'wpfd'); ?></label>
        <div class="controls">
            <input title="" name="params[ggd_croptitle]" value="<?php echo esc_attr($this->params['ggd_croptitle']); ?>"
                   class="inputbox input-block-level croptitle" type="text">
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="showsize"><?php esc_html_e('Show weight', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[ggd_showsize]" class="inline">
                <option value="1" <?php echo ((int) $this->params['ggd_showsize'] === 1) ? 'selected="selected"' : ''; ?>>
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['ggd_showsize'] === 0) ? 'selected="selected"' : ''; ?>>
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>

    <div class="control-group">
        <label class="control-label" for="showversion"><?php esc_html_e('Show version', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[ggd_showversion]" class="inline">
                <option value="1" <?php echo ((int) $this->params['ggd_showversion'] === 1) ? 'selected="selected"' : ''; ?>>
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['ggd_showversion'] === 0) ? 'selected="selected"' : ''; ?>>
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="showhits"><?php esc_html_e('Show hits', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[ggd_showhits]" class="inline">
                <option value="1" <?php echo ((int) $this->params['ggd_showhits'] === 1) ? 'selected="selected"' : ''; ?>>
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['ggd_showhits'] === 0) ? 'selected="selected"' : ''; ?>>
                    <?php esc_html_e('No', 'wpfd'); ?></option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="showdownload"><?php esc_html_e('Show download link', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[ggd_showdownload]" class="inline">
                <option value="1" <?php echo ((int) $this->params['ggd_showdownload'] === 1) ? 'selected="selected"' : ''; ?>>
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['ggd_showdownload'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="showdateadd"><?php esc_html_e('Show date added', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[ggd_showdateadd]" class="inline">
                <option value="1" <?php echo ((int) $this->params['ggd_showdateadd'] === 1) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['ggd_showdateadd'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="showdatemodified"><?php esc_html_e('Show date modified', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[ggd_showdatemodified]" class="inline">
                <option value="1"
                    <?php echo ((int) $this->params['ggd_showdatemodified'] === 1) ? 'selected="selected"' : ''; ?>>
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0"
                    <?php echo ((int) $this->params['ggd_showdatemodified'] === 0) ? 'selected="selected"' : ''; ?>>
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="ggd_download_popup"><?php esc_html_e('Download popup', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[ggd_download_popup]" class="inline">
                <option value="1" <?php echo ((int) $this->params['ggd_download_popup'] === 1) ? 'selected="selected"' : ''; ?>>
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['ggd_download_popup'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="ggd_bgdownloadlink"><?php esc_html_e('Background download link', 'wpfd'); ?></label>
        <div class="controls">
            <input title="" name="params[ggd_bgdownloadlink]" value="<?php echo esc_attr($this->params['ggd_bgdownloadlink']); ?>"
                   class="inputbox input-block-level wp-color-field" type="text">
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="ggd_colordownloadlink"><?php esc_html_e('Color download link', 'wpfd'); ?></label>
        <div class="controls">
            <input title="" name="params[ggd_colordownloadlink]"
                   value="<?php echo esc_attr($this->params['ggd_colordownloadlink']); ?>"
                   class="inputbox input-block-level wp-color-field" type="text">
        </div>
    </div>
</fieldset>

