<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

// No direct access.
defined('ABSPATH') || die();

?>
<fieldset>
    <legend><?php esc_html_e('Category layout', 'wpfd'); ?></legend>
    <div class="control-group">
        <label class="control-label" for="tree_showbgtitle"><?php esc_html_e('Background title', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[tree_showbgtitle]" class="inline">
                <option value="1" <?php echo ((int) $this->params['tree_showbgtitle'] === 1) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['tree_showbgtitle'] === 0) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="tree_showtreeborder"><?php esc_html_e('Show tree border', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[tree_showtreeborder]" class="inline">
                <option value="1" <?php echo ((int) $this->params['tree_showtreeborder'] === 1) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['tree_showtreeborder'] === 0) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="tree_showcategorytitle"><?php esc_html_e('Show category title', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[tree_showcategorytitle]" class="inline">
                <option value="1"
                    <?php echo ((int) $this->params['tree_showcategorytitle'] === 1) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0"
                    <?php echo ((int) $this->params['tree_showcategorytitle'] === 0) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="showsubcategories"><?php esc_html_e('Show subcategories', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[tree_showsubcategories]" class="inline">
                <option value="1"
                    <?php echo ((int) $this->params['tree_showsubcategories'] === 1) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0"
                    <?php echo ((int) $this->params['tree_showsubcategories'] === 0) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="tree_download_popup"><?php esc_html_e('Download popup', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[tree_download_popup]" class="inline">
                <option value="1" <?php echo ((int) $this->params['tree_download_popup'] === 1) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['tree_download_popup'] === 0) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
</fieldset>
<fieldset>
    <legend><?php esc_html_e('File layout', 'wpfd'); ?></legend>
    <div class="control-group">
        <label class="control-label" for="showtitle"><?php esc_html_e('Show title', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[tree_showtitle]" class="inline">
                <option value="1" <?php echo ((int) $this->params['tree_showtitle'] === 1) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['tree_showtitle'] === 0) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="croptitle"><?php esc_html_e('Crop titles', 'wpfd'); ?></label>
        <div class="controls">
            <input title="" name="params[tree_croptitle]" value="<?php echo esc_attr($this->params['tree_croptitle']); ?>"
                   class="inputbox input-block-level croptitle" type="text">
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="showsize"><?php esc_html_e('Show weight', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[tree_showsize]" class="inline">
                <option value="1" <?php echo ((int) $this->params['tree_showsize'] === 1) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['tree_showsize'] === 0) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>

    <div class="control-group">
        <label class="control-label" for="showversion"><?php esc_html_e('Show version', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[tree_showversion]" class="inline">
                <option value="1" <?php echo ((int) $this->params['tree_showversion'] === 1) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['tree_showversion'] === 0) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="showhits"><?php esc_html_e('Show hits', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[tree_showhits]" class="inline">
                <option value="1" <?php echo ((int) $this->params['tree_showhits'] === 1) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['tree_showhits'] === 0) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="showdownload"><?php esc_html_e('Show download link', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[tree_showdownload]" class="inline">
                <option value="1" <?php echo ((int) $this->params['tree_showdownload'] === 1) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['tree_showdownload'] === 0) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="showdateadd"><?php esc_html_e('Show date added', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[tree_showdateadd]" class="inline">
                <option value="1" <?php echo ((int) $this->params['tree_showdateadd'] === 1) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['tree_showdateadd'] === 0) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="showdatemodified"><?php esc_html_e('Show date modified', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[tree_showdatemodified]" class="inline">
                <option value="1"
                    <?php echo ((int) $this->params['tree_showdatemodified'] === 1) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0"
                    <?php echo ((int) $this->params['tree_showdatemodified'] === 0) ? 'selected="selected"' : '' ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="tree_bgdownloadlink"><?php esc_html_e('Background download link', 'wpfd'); ?></label>
        <div class="controls">
            <input title="" name="params[tree_bgdownloadlink]"
                   value="<?php echo esc_attr($this->params['tree_bgdownloadlink']); ?>"
                   class="inputbox input-block-level wp-color-field" type="text">
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="table_colordownloadlink"><?php esc_html_e('Color download link', 'wpfd'); ?></label>
        <div class="controls">
            <input title="" name="params[tree_colordownloadlink]"
                   value="<?php echo esc_attr($this->params['tree_colordownloadlink']); ?>"
                   class="inputbox input-block-level wp-color-field" type="text">
        </div>
    </div>
</fieldset>

