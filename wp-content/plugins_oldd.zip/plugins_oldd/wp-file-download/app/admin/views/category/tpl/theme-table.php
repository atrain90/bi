<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

// No direct access.
defined('ABSPATH') || die();

?>
<fieldset>
    <legend><?php esc_html_e('Category layout', 'wpfd'); ?></legend>
    <div class="control-group">
        <label class="control-label" for="table_styling"><?php esc_html_e('Stylize table', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[table_styling]" class="inline">
                <option value="1" <?php echo ((int) $this->params['table_styling'] === 1) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['table_styling'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="table_stylingmenu"><?php esc_html_e('Stylize menu', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[table_stylingmenu]" class="inline">
                <option value="1" <?php echo ((int) $this->params['table_stylingmenu'] === 1) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['table_stylingmenu'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="table_showcategorytitle"><?php esc_html_e('Show category title', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[table_showcategorytitle]" class="inline">
                <option value="1"
                    <?php echo ((int) $this->params['table_showcategorytitle'] === 1) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0"
                    <?php echo ((int) $this->params['table_showcategorytitle'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="showsubcategories"><?php esc_html_e('Show subcategories', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[table_showsubcategories]" class="inline">
                <option value="1"
                    <?php echo ((int) $this->params['table_showsubcategories'] === 1) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0"
                    <?php echo ((int) $this->params['table_showsubcategories'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="table_showbreadcrumb"><?php esc_html_e('Show Breadcrumb', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[table_showbreadcrumb]" class="inline">
                <option value="1"
                    <?php echo ((int) $this->params['table_showbreadcrumb'] === 1) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0"
                    <?php echo ((int) $this->params['table_showbreadcrumb'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="table_showfoldertree"><?php esc_html_e('Show folder tree', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[table_showfoldertree]" class="inline">
                <option value="1"
                    <?php echo ((int) $this->params['table_showfoldertree'] === 1) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0"
                    <?php echo ((int) $this->params['table_showfoldertree'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
</fieldset>
<fieldset>
    <legend><?php esc_html_e('File block layout', 'wpfd'); ?></legend>
    <div class="control-group">
        <label class="control-label" for="showtitle"><?php esc_html_e('Show title', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[table_showtitle]" class="inline">
                <option value="1" <?php echo ((int) $this->params['table_showtitle'] === 1) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['table_showtitle'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="croptitle"><?php esc_html_e('Crop titles', 'wpfd'); ?></label>
        <div class="controls">
            <input title="" name="params[table_croptitle]" value="<?php echo esc_attr($this->params['table_croptitle']); ?>"
                   class="inputbox input-block-level croptitle" type="text">
        </div>
    </div>
    <div class="control-group">
        <label class="control-label"
               for="params[table_showdescription]"><?php esc_html_e('Show description', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[table_showdescription]" class="inline">
                <option value="1"
                    <?php echo ((int) $this->params['table_showdescription'] === 1) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0"
                    <?php echo ((int) $this->params['table_showdescription'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>

    <div class="control-group">
        <label class="control-label" for="showsize"><?php esc_html_e('Show weight', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[table_showsize]" class="inline">
                <option value="1" <?php echo ((int) $this->params['table_showsize'] === 1) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['table_showsize'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>

    <div class="control-group">
        <label class="control-label" for="showversion"><?php esc_html_e('Show version', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[table_showversion]" class="inline">
                <option value="1" <?php echo ((int) $this->params['table_showversion'] === 1) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['table_showversion'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="showhits"><?php esc_html_e('Show hits', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[table_showhits]" class="inline">
                <option value="1" <?php echo ((int) $this->params['table_showhits'] === 1) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['table_showhits'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="showdownload"><?php esc_html_e('Show download link', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[table_showdownload]" class="inline">
                <option value="1" <?php echo ((int) $this->params['table_showdownload'] === 1) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['table_showdownload'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="showdateadd"><?php esc_html_e('Show date added', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[table_showdateadd]" class="inline">
                <option value="1" <?php echo ((int) $this->params['table_showdateadd'] === 1) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0" <?php echo ((int) $this->params['table_showdateadd'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="showdatemodified"><?php esc_html_e('Show date modified', 'wpfd'); ?></label>
        <div class="controls">
            <select title="" name="params[table_showdatemodified]" class="inline">
                <option value="1"
                    <?php echo ((int) $this->params['table_showdatemodified'] === 1) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('Yes', 'wpfd'); ?>
                </option>
                <option value="0"
                    <?php echo ((int) $this->params['table_showdatemodified'] === 0) ? 'selected="selected"' : ''; ?> >
                    <?php esc_html_e('No', 'wpfd'); ?>
                </option>
            </select>
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="table_bgdownloadlink"><?php esc_html_e('Background download link', 'wpfd'); ?></label>
        <div class="controls">
            <input title="" name="params[table_bgdownloadlink]"
                   value="<?php echo esc_attr($this->params['table_bgdownloadlink']); ?>"
                   class="inputbox input-block-level wp-color-field" type="text">
        </div>
    </div>
    <div class="control-group">
        <label class="control-label" for="table_colordownloadlink"><?php esc_html_e('Color download link', 'wpfd'); ?></label>
        <div class="controls">
            <input title="" name="params[table_colordownloadlink]"
                   value="<?php echo esc_attr($this->params['table_colordownloadlink']); ?>"
                   class="inputbox input-block-level wp-color-field" type="text">
        </div>
    </div>
</fieldset>

