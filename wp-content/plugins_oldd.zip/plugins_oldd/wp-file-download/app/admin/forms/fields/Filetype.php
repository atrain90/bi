<?php
/**
 * WP File Download
 *
 * @package WP File Download
 * @author  Joomunited
 * @version 1.0
 */

namespace Joomunited\WP_File_Download\Admin\Fields;

use Joomunited\WPFramework\v1_0_4\Field;
use Joomunited\WPFramework\v1_0_4\Application;
use Joomunited\WPFramework\v1_0_4\Model;

defined('ABSPATH') || die();

/**
 * Class Filetype
 */
class Filetype extends Field
{
    /**
     * Display field file type
     *
     * @param array $field Fields
     *
     * @return string
     */
    public function getfield($field)
    {
        $attributes = $field['@attributes'];
        $html = '';
        $tooltip = isset($attributes['tooltip']) ? $attributes['tooltip'] : '';
        if (empty($attributes['hidden']) || (!empty($attributes['hidden']) && $attributes['hidden'] !== 'true')) {
            $html .= '<div class="control-group wpfd-hide">';
            if (!empty($attributes['label']) && $attributes['label'] !== '' &&
                !empty($attributes['name']) && $attributes['name'] !== '') {
                $html .= '<label title="' . $tooltip . '" class="control-label" for="' . $attributes['name'] . '">';
                // phpcs:ignore WordPress.WP.I18n.NonSingularStringLiteralText -- Dynamic translate
                $html .= esc_html__($attributes['label'], 'wpfd') . '</label>';
            }
            $html .= '<div class="controls">';
        }
        $html .= '<select';
        if (!empty($attributes)) {
            foreach ($attributes as $attribute => $value) {
                if (in_array($attribute, array('id', 'class', 'onchange', 'name')) && isset($value)) {
                    $html .= ' ' . $attribute . '="' . $value . '"';
                }
            }
        }
        $html .= ' >';
        Application::getInstance('Wpfd');
        $modelConfig = Model::getInstance('config');
        $config = $modelConfig->getConfig();
        $allowed_ext = explode(',', $config['allowedext']);
        foreach ($allowed_ext as $key => $value) {
            $html .= '<option value="' . $value . '" ';
            if (isset($attributes['value']) && $attributes['value'] === $value) {
                $html .= ' selected="selected"';
            }
            $html .= '>';
            $html .= $value;
            $html .= '</option>';
        }
        $html .= '</select>';
        if (!empty($attributes['type']) || (!empty($attributes['hidden']) && $attributes['hidden'] !== 'true')) {
            $html .= '</div></div>';
        }
        return $html;
    }
}
